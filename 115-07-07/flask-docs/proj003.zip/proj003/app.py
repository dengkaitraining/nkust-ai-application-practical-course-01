from flask import Flask, send_file, render_template
import random



app = Flask(__name__)

@app.route("/")
def home():
    return app.send_static_file("index.html") #將 index.html送到Brower


@app.route("/dynamic") 
def dynamic():
   # 隨機生成一個0到50的數字，儲存到 dog 變數
   dog = random.randint(0, 50)
   print(dog)
   return render_template("lucky.html",num=dog)
	
@app.route("/myimg")
def image():
    return send_file("static/test.jpg", mimetype="image/jpeg")
	
@app.route("/mydoc")
def docx():
    return send_file("static/test.docx")


	
	
if __name__ == "__main__":
    app.run(debug=True) 