from sklearn.svm import SVC
import numpy as np

X=np.array([[1,4],[2,3],[3,3],[6,5],[7,4],[8,3],[4,6],[3,9],[5,7]])
y=['A','A','A','B','B','B','C','C','C']

#第一個SVM分類器
s1=['A','A','A','D','D','D','D','D','D']
model_1=SVC()
model_1.fit(X,s1)

#第二個SVM分類器
s2=['E','E','E','B','B','B','E','E','E']
model_2=SVC()
model_2.fit(X,s2)

#第三個SVM分類器
s3=['F','F','F','F','F','F','C','C','C']
model_3=SVC()
model_3.fit(X,s3)

def classify(testX):
   y_pred=model_1.predict(testX)
   if (y_pred == 'A'):
        return 'A'

   else:
       y_pred=model_2.predict(testX)
       if (y_pred == 'B'):
           return 'B'
       else:
           y_pred=model_3.predict(testX)
           if (y_pred == 'C'):
              return  'C'
           else:
              return 'G'
result=[]
for x in X:
    testX = x.reshape(1, 2)
    result.append(classify(testX))
    
print(result)


