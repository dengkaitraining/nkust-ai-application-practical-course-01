from sklearn.svm import SVC

X=[[1,1],[1,-1],[-1,1],[-1,-1],[2,2],[2,-2],[-2,2],[-2,-2]]
#y=[-1,-1,-1,-1,1,1,1,1]
y=['A','A','A','A','B','B','B','B']
model=SVC(kernel="linear")
model.fit(X,y)

y_pred=model.predict(X)
print('分類結果為 ', y_pred)   #分類結果為 ['B' 'B' 'B' 'B' 'B' 'B' 'B' 'B']

