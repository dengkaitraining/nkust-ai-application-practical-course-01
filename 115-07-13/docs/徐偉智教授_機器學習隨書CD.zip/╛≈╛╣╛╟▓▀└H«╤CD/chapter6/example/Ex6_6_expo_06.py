import numpy as np
import math

alpha=[] ;  VC=[]
f = open("rbfSVM.txt", "r")
N=int(f.readline())
for i in range(0,N):
   alpha.append(float(f.readline()))
   vctxt=f.readline();   txt=vctxt.split();   txt=list(map(float,txt))
   VC.append(txt)
b=float(f.readline())
gamma=float(f.readline())
f.close()

def rbfDecision(newX,alpha,VC,b,gamma):   
    N=len(alpha);   total=0
    for i in range(0,N):
        subX=newX-VC[i]; kpart=math.exp(-gamma*subX.dot(subX))
        kpart=alpha[i]*kpart
        total=total + kpart
    value=total+b
    if (value <= 0.0):
        return -1
    else:
        return 1


X=[[0.5,0.5],[1,1],[1,-1],[-1,1],[-1,-1],   [2,2],[2,-2],[-2,2],[-2,-2],[3,-3]]
y=[1,1,1,1,1,-1,-1,-1,-1,-1]        
while(True):
   xin=input("請給定輸入向量:   ")
   if (xin =='Q' or xin =='q'):
       break
   else: 
      newX=xin.split();   newX=list(map(float,newX))
      newX=np.array(newX)
      result=rbfDecision(newX,alpha,VC,b,gamma)
      print("分類的結果是標記 ", result)
 
