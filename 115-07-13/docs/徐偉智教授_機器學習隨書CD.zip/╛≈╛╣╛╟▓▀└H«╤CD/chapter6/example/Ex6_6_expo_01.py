import matplotlib.pyplot as plt
from sklearn.svm import SVC
import numpy as np

X=np.array([ [-1,3],[-3,2],[1,3],[4,4],[-5,-2],[2,-3],[-2,-1],[3,1] ])
y=[1,1,1,1,-1,-1,-1,-1]

model=SVC(kernel="linear")
model.fit(X,y)

print("Alpha: ", model.dual_coef_) 
print("VC: \n", model.support_vectors_)
print("b: ", model.intercept_)

alpha=model.dual_coef_
VC=model.support_vectors_
b=model.intercept_
N=len(alpha[0])
L=len(VC[0])

f = open("linearSVM.txt", "w")
f.write(str(N) + "\n")
for i in range(0,N):
   f.write(str(alpha[0,i]) + "\n")
   for k in range(0,L):
      f.write(str(VC[i,k]) + "  ")
   f.write("\n")
f.write(str(b[0]) + "\n")
f.close()

plt.plot(X[0:4,0],X[0:4,1],'o')
plt.plot(X[4:8,0],X[4:8,1],'x')
plt.show()


