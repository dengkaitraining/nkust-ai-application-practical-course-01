from sklearn.svm import SVC
import numpy as np

X=np.array([[1,4],[2,3],[3,3],[6,5],[7,4],[8,3],[4,6],[3,9],[5,7]])
y=['A','A','A','B','B','B','C','C','C']

model=SVC()    
model.fit(X,y)

result=model.predict(X)
print("分類結果為:  ", result) #分類結果為: ['A' 'A' 'A' 'B' 'B' 'B' 'C' 'C' 'C']



           
        

