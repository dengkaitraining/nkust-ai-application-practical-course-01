from sklearn import linear_model
import numpy as np

def estimate(w,c,x):
    est=w[0]*x[0]+w[1]*x[1]+c
    return np.round(est,2)

def check(val):
    if val>=0:
        return 1
    else:
        return -1

prediction=[]

X=[[181,89],[149,76],[162,82],[171,61],[186,75],[182,70]]
s=[[1],[1],[1],[-1],[-1],[-1]]

regr = linear_model.LinearRegression()
regr.fit(X, s)
w=regr.coef_[0,:]
c=regr.intercept_[0]
print(c,w)

for  x in X:
    vest=estimate(w,c,x)
    prediction.append(vest)
print(prediction)

result=list(map(check,prediction))
print()
print(result)




