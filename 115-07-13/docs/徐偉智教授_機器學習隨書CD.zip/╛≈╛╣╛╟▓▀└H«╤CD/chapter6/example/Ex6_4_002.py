from sklearn.svm import SVC
import math
import numpy as np

X=np.array([[1,1],[1,-1],[-1,1],[-1,-1],[2,2],[2,-2],[-2,2],[-2,-2]])
y=['A','A','A','A','B','B','B','B']
x1=X[:,0]
x2=X[:,1]
new_x1=np.power(x1,2.0)
new_x2=np.power(x2,2.0)
new_x3=math.sqrt(2)*x1*x2

newX=np.stack((new_x1,new_x2,new_x3),axis=1)

model=SVC(kernel="linear")
model.fit(newX,y)

print("w1,w2,w3 is : ",model.coef_)
print("b is : ", model.intercept_)
y_pred=model.predict(newX)
print('分類結果為 ', y_pred)   # 分類結果為 ['A' 'A' 'A' 'A' 'B' 'B' 'B' 'B']

