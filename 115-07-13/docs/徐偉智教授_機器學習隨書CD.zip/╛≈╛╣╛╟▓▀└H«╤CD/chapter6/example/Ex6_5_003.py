from sklearn import  datasets
from sklearn.svm import SVC

# 讀入鳶尾花資料
iris = datasets.load_iris()
iris_X = iris.data   #取出自變數陣列
y = iris.target      #取出依變數陣列

model=SVC(kernel='rbf',C=2.0,gamma=2.0)    
model.fit(iris_X,y)

print("SV數目為: ", len(model.support_vectors_))
result=model.predict(iris_X)
print("分類結果為:  ")
print(result)
"""
SV數目為:  59
分類結果為:  
[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
 1 1 1 2 1 1 1 1 1 2 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 1 2 2 2 2
 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 1 2 2 2 2 2 2 2 2 2
 2 2]
 """

