import numpy as np

alpha=[] ;  VC=[]
f = open("polySVM.txt", "r")
N=int(f.readline())
for i in range(0,N):
   alpha.append(float(f.readline()))
   vctxt=f.readline();   txt=vctxt.split();   txt=list(map(float,txt))
   VC.append(txt)
b=float(f.readline())
gamma=float(f.readline())
coef0=float(f.readline())
degree=float(f.readline())
f.close()

def polyDecision(newX,alpha,VC,b,gamma,coef0,degree):   
    N=len(alpha)
    total=0
    for i in range(0,N):
        kpart=gamma*newX.dot(VC[i]) + coef0
        kpart=alpha[i]*np.power(kpart,degree)
        total=total + kpart
    value=total+b
    if (value <= 0.0):
        return -1
    else:
        return 1
        
while(True):
   xin=input("請給定輸入向量:   ")
   if (xin =='Q' or xin =='q'):
       break
   else: 
      newX=xin.split();   newX=list(map(float,newX))
      newX=np.array(newX)
      result=polyDecision(newX,alpha,VC,b,gamma,coef0,degree)
      print("分類的結果是標記 ", result)
 
