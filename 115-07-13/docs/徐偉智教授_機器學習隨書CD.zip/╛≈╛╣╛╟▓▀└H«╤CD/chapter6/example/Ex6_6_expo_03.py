from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import numpy as np

X=[[0.5,0.5],[1,1],[1,-1],[-1,1],[-1,-1],[2,2],[2,-2],[-2,2],[-2,-2],[3,-3]]
y=[1,1,1,1,1,-1,-1,-1,-1,-1]


model=SVC(kernel="poly",gamma=1.0,degree=2,coef0=0.0)
model.fit(X,y)

print("kernel function 是 ",model.kernel)
print("Alpha: ", model.dual_coef_) 
print("VC: \n", model.support_vectors_)
print("b: ", model.intercept_)
print("Gama是 ",model.gamma)
print("d是 ", model.degree)
print("r 是 ", model.coef0)

alpha=model.dual_coef_
VC=model.support_vectors_
b=model.intercept_
N=len(alpha[0])
L=len(VC[0])

f = open("polySVM.txt", "w")
f.write(str(N) + "\n")
for i in range(0,N):
   f.write(str(alpha[0,i]) + "\n")
   for k in range(0,L):
      f.write(str(VC[i,k]) + "  ")
   f.write("\n")
f.write(str(b[0]) + "\n")
f.write(str(model.gamma)+"\n")
f.write(str(model.coef0)+"\n")
f.write(str(model.degree)+"\n")
f.close()

y_pred=model.predict(X)
print(f'Accuracy : {accuracy_score(y,y_pred)}')



