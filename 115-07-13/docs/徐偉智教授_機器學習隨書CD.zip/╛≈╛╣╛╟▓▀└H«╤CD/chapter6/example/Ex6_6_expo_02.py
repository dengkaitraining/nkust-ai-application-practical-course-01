import numpy as np

def decisionFun(X,alpha,VC,b):
    N=len(alpha)
    total=0.0
    for i in range(0,N):
      t1=X.dot(VC[i])
      t1=alpha[i]*t1
      total=total + t1
    val=total+b
    if (val <= 0.0):
        return -1
    else:
        return 1

alpha=[]
VC=[]
f = open("linearSVM.txt", "r")
N=int(f.readline())
for i in range(0,N):
   alpha.append(float(f.readline()))
   vctxt=f.readline()
   txt=vctxt.split()
   txt=list(map(float,txt))
   VC.append(txt)
b=float(f.readline())
f.close()

print(alpha)
print(VC)
print(b)


#X=np.array([ [-1,3],[-3,2],[1,3],[4,4],[-5,-2],[2,-3],[-2,-1],[3,1] ])
#y=[1,1,1,1,-1,-1,-1,-1]

while(True):
   xin=input("請給定輸入向量:   ")
   if (xin =='Q' or xin =='q'):
       break
   else: 
      X=xin.split()
      X=list(map(float,X))
      X=np.array(X)
      result=decisionFun(X,alpha,VC,b)
      print("分類的結果是標記 ", result)
 





