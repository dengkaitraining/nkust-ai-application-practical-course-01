from sklearn.svm import SVC
import math
import numpy as np

X=np.array([[1,1],[1,-1],[-1,1],[-1,-1],[2,2],[2,-2],[-2,2],[-2,-2]])
y=['A','A','A','A','B','B','B','B']

model=SVC()
model.fit(X,y)

y_pred=model.predict(X)
print('分類結果為 ', y_pred)  #分類結果為  ['A' 'A' 'A' 'A' 'B' 'B' 'B' 'B']

