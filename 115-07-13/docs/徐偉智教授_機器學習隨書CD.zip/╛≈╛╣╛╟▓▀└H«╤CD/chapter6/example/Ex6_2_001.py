from sklearn.svm import SVC

X=[[1,0],[0,-1],[0,0],[2,3],[3,0],[0,-3],[2,-4],[4,-4]]
#y=[-1,-1,-1,-1,1,1,1,1]
y=['A','A','A','A','B','B','B','B']
model=SVC(kernel="linear")
model.fit(X,y)

print('w1與w2是: ',model.coef_[0,0],model.coef_[0,1]) 
print('b是: ', model.intercept_[0]) 

print("Support Vectors are : ")
print(model.support_vectors_)

y_pred=model.predict(X)
print('分類結果為 ', y_pred)

