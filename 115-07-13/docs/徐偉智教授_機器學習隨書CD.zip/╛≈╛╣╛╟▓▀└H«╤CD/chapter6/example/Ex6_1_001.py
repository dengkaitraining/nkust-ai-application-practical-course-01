import matplotlib.pyplot as plt
import numpy as np

xpoints = np.array([149,162,181])
ypoints = np.array([76,82,89])
plt.plot(xpoints, ypoints, 'o')

xpoints = np.array([171,182,186])
ypoints = np.array([61,70,75])
plt.plot(xpoints, ypoints, 'x')

xpoints = np.array([148,190])
ypoints = np.array([61,88])
plt.plot(xpoints,ypoints, linestyle = 'dotted')

plt.show()
