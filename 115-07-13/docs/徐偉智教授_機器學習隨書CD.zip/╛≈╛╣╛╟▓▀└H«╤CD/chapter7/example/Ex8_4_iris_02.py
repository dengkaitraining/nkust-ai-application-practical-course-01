Sepal_Length=float(input("請輸入花萼長度: "))
Sepal_Width=float(input("請輸入花萼寬度: "))
Petal_Length=float(input("請輸入花瓣長度: "))
Petal_Width=float(input("請輸入花瓣寬度: "))

if (Petal_Length <= 2.45):
    print("分類為 setosa")
else:
    if (Petal_Width <= 1.75):
        if (Petal_Length <= 4.95):
            print("分類為 versicolor")
        else:
            print("分類為 virginica")
    else:
        if (Petal_Length <= 4.85):
            print("分類為 virginica")
        else:
            print("分類為 virginica")
