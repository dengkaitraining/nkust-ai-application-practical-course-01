from sklearn.neural_network import MLPClassifier

X=[[1.1,1.1],[1.2,-1.2],[-1.3,-1.3],[-1.4,1.4],[2.1,2.1],[2.2,-2.2],[-2.3,-2.3],[-2.4,2.4]]
y=[[1,0],[1,0],[1,0],[1,0],[0,1],[0,1],[0,1],[0,1]]

#2x2x1x2
#2x2 , 2x1, 1x2

#2x3x2 ,
#2x3  ,  3x2
myann = MLPClassifier(activation='logistic',
                      hidden_layer_sizes=(3,), solver='lbfgs', random_state=500
)
myann.fit(X, y)

#myann.coefs_  是List
weights=myann.coefs_
bias=myann.intercepts_

weiInHidden=weights[0]     #2x3 的weights 矩陣
print("輸入層到隱藏層的weights矩陣:\n",weiInHidden)

print("輸入層第一個neuron到隱藏層的第一個neuron的weight")
print(weiInHidden[0][0])  #weights[0][0][0]

weiHiddenOut=weights[1]   #3x3 的weights 矩陣
print("隱藏層到輸出層的weights矩陣:")
print(weiHiddenOut)
print("隱藏層第二個neuron到輸出層的第二個neuron的weight:")
print(weiHiddenOut[1][1])

print("偏差值串列: ")
print(bias)

print("隱藏層第二個neuron的偏差值: ",bias[0][1])
print("輸出層第一個neuron的偏差值: ",bias[1][0])


print(f'best_loss_:{myann.loss_}')
result=myann.predict(X)
print("分類結果為： ")
print(result)
accuracy=myann.score(X,y)
print("準確率為: ", accuracy)


