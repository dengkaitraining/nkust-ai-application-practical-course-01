import numpy as np
import pandas as pd
from   sklearn import tree
from   sklearn.tree import DecisionTreeClassifier
from   sklearn.tree import export_text
import matplotlib.pyplot as plt

#使用Dictionary 建立DataFrame
grades = {
    "wType" : ["cloudy","cloudy","cloudy","cloudy","sunny",
"sunny","sunny","sunny","sunny","rainy","rainy","rainy","rainy","rainy","rainy"],
   "Temp" : [29,24,27,26,31,33,34,28,27,28,26,20,28,27,29],
   "Hum" : [50,49,52,56,55,61,59,58,55,62,63,70,55,54,50]
}
trnX = pd.DataFrame(grades)
d = {'cloudy': 0, 'sunny': 1, 'rainy': 2}
trnX['wType'] = trnX['wType'].map(d)

Dec = {"Decision":["Play","Play","Play","Play","NoPlay","NoPlay",
"NoPlay","Play","Play","NoPlay","NoPlay","NoPlay",
"Play","Play","Play"]
}
y = pd.DataFrame(Dec)
d = {'Play': 1, 'NoPlay': 0}
y['Decision'] = y['Decision'].map(d)

features = ['wType', 'Temp', 'Humudity']
dtree = DecisionTreeClassifier(criterion="entropy")
dtree = dtree.fit(trnX, y)

r = export_text(dtree, feature_names=features)
print(r)
print(dtree.predict(trnX[:5]))

tree.plot_tree(dtree)
plt.show()
