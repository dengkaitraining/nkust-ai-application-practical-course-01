from sklearn.datasets import load_iris
from sklearn import tree
import matplotlib.pyplot as plt
from sklearn.metrics import  confusion_matrix

iris = load_iris()
X, y = iris.data, iris.target
clf = tree.DecisionTreeClassifier(min_samples_split=4,max_depth=3)
clf = clf.fit(X, y)
result=clf.predict(X)

conMtx=confusion_matrix(y,result)
print(conMtx)

tree.plot_tree(clf)
plt.show()
