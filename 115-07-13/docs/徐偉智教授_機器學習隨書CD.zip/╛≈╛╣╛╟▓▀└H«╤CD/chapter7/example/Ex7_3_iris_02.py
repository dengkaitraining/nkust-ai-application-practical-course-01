from sklearn import datasets
from sklearn.neural_network import MLPClassifier
import numpy as np
iris = datasets.load_iris()
X = iris.data   
y = iris.target

model = MLPClassifier(solver='lbfgs', activation='logistic',
                        hidden_layer_sizes=(2,))
model.fit(X, y)

print(" 迭代總次數為:",model.n_iter_)
print(" 誤差平方和為：", np.round(model.loss_,3))
print(" 權重為: ",model.coefs_ )
print(" 偏差值為: ",model.intercepts_)
