
import math

def getEntropy(p):
  Entropy=0  #uncertainty
  for a in p:
     if (a!=0) and (a!=1):
       Entropy=Entropy + (-a)*math.log2(a)
  return Entropy

p=[1/6,5/6]

wei=[9/15,6/15]
p0=[9/15,6/15]
p1=[6/9,3/9]
p2=[3/6,3/6]
IG=getEntropy(p0)-(wei[0]*getEntropy(p1) + wei[1]*getEntropy(p2))
print(IG)
