from sklearn.datasets import load_iris
from sklearn import tree
import matplotlib.pyplot as plt
from sklearn.metrics import  confusion_matrix
from   sklearn.tree import export_text

iris = load_iris()
X, y = iris.data, iris.target
clf = tree.DecisionTreeClassifier(criterion="entropy")
clf = clf.fit(X, y)
result=clf.predict(X)
accuracy=clf.score(X, y)
print("分類準確率為： ",accuracy)

conMtx=confusion_matrix(y,result)
print("混淆矩陣:")
print(conMtx)

tree.plot_tree(clf)
plt.show()
