import matplotlib.pyplot as plt
import numpy as np
X=np.array([[1.1,1.1],[1.2,-1.2],[-1.3,-1.3],[-1.4,1.4],
            [2.1,2.1],[2.2,-2.2],[-2.3,-2.3],[-2.4,2.4]])

plt.plot(X[0:4,0],X[0:4,1],'o')
plt.plot(X[4:8,0],X[4:8,1],'x')
plt.xlabel("x1")
plt.ylabel("x2")
plt.show()



