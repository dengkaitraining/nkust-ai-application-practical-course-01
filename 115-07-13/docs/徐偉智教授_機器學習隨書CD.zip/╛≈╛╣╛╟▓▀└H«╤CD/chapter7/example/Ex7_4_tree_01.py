weather_Type=input("請輸入Weather_Type：{Rainy,Sunny,or Cloudy}：")
Temperature=input("請輸入Temperature：")
Temperature=int(Temperature)
Humidity=input("請輸入Humudity：")
Humidity=int(Humidity)

if (weather_Type =="Cloudy"):
    print("打球")
else:
    if (weather_Type =="Sunny"):
        if (Temperature > 30):
          print("不打球")
        else:
          print("打球") 
    else:
        if (Humidity > 60):
          print("不打球")
        else:
          print("打球") 
            
    
            
    
                   
                   
                
