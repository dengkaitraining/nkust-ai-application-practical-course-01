from sklearn import datasets
from sklearn.neural_network import MLPClassifier
import numpy as np
iris = datasets.load_iris()
X = iris.data   
y = iris.target

model_1 = MLPClassifier(solver='lbfgs', activation='logistic',
                          hidden_layer_sizes=(2,), random_state=400)
model_1.fit(X, y)
accuracy=model_1.score(X,y)
print("優化權重設為 lbfgs 時，")
print("  迭代總次數為:",model_1.n_iter_)
print("  誤差平方和為：", np.round(model_1.loss_,3))
print("  準確率為: ", np.round(accuracy,3))

model_2 = MLPClassifier(solver='adam', activation='logistic',
        hidden_layer_sizes=2, random_state=400,max_iter=10000)
model_2.fit(X, y)
accuracy=model_2.score(X,y)
print("lbfgs改為adam時，")
print("  迭代總次數為:",model_2.n_iter_)
print("  誤差平方和為：", np.round(model_2.loss_,3))
print("  準確率為: ", np.round(accuracy,3))

model_3 = MLPClassifier(solver='lbfgs', activation='relu',
        hidden_layer_sizes=2, random_state=400)
model_3.fit(X, y)
accuracy=model_3.score(X,y)
print("將activation由logistic改為relu時，")
print("  迭代總次數為:",model_3.n_iter_)
print("  誤差平方和為：", np.round(model_3.loss_,3))
print("  準確率為: ", np.round(accuracy,3))

model_4 = MLPClassifier(solver='lbfgs', activation='logistic',
        hidden_layer_sizes=(2,3), random_state=400,max_iter=300)
model_4.fit(X, y)
accuracy=model_4.score(X,y)
print("將隱藏層由(2,) 改為(2,3)時，")
print("   迭代總次數為:",model_4.n_iter_)
print("   誤差平方和為：", np.round(model_4.loss_,3))
print("   準確率為: ", np.round(accuracy,3))
