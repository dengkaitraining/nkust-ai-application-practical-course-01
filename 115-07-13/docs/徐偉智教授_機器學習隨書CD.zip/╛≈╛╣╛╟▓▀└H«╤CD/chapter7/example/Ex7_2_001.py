import math
import numpy as np


def Act_Fun(u):
    result = 1.0/(1.0+math.exp(-u))
    return result


def NN_Service(a1,a2,a3,a4):
   z1 = 1*( 2.05789 ) + a1*(0.70374)  + a2*(-7.76402) + a3*(2.23409) + a4*(11.6457)
   u1 = Act_Fun(z1)

   z2 = 1*(28.56989)+a1*(2.01617)+a2*(5.07655)+a3*(-6.73166)+a4*(-13.4051)
   u2 = Act_Fun(z2)

   o1 = 1*(1.00058)+u1*(-1.00054)+u2*(-0.00053)
   setosa = Act_Fun(o1)
   
   o2 = 1*(-1.0138)+u1*(1.00489)+u2*(1.01346)
   versicolor = Act_Fun(o2)
   
   o3 = 1*(1.0133)+u1*(-0.00394)+u2*(-1.01307)
   mirginica = Act_Fun(o3)
   
   if  (setosa > versicolor) and (setosa > mirginica) :
       return [1,0,0]
   elif (versicolor > mirginica) and (versicolor > setosa):
       return [0,1,0]
   else:
       return [0,0,1]
    
  

result=NN_Service(5.7,2.8,4.1,1.3)
print(result)  #[0,1,0]
