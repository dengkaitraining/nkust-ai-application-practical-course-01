def alert():
  print("beep! beep!")
temp=89
if (temp > 76):
  alert()      #  beep! beep! 出現在主控台畫面 









