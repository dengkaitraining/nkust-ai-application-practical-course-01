def my_function(fname, lname):
  print(fname + " " + lname)   #輸入的引數值就代入到這些參數

my_function("Emil","test")     #呼叫自行定義的my_function(…)
                               #Email test








