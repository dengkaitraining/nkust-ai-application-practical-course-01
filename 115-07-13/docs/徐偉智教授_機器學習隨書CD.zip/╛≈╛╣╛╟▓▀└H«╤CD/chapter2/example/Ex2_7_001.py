import numpy          #引入到直譯器環境
dog=numpy.log2(8)     # 呼叫 numpy 的 log2(...)功能單元
print("結果是",dog)   #結果是 3.0

print(type(100))      #<class 'int'>

print(type("Taiwan")) #<class 'str'>










