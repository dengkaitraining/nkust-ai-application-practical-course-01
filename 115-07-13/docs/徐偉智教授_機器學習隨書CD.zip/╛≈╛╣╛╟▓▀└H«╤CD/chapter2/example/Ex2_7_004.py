def  add2(a,b):      #a與b只是function內部的區域變數(local variable)
  val=a+b
  return val         #將val回傳至呼叫處

x=3
y=9
dog=add2(x,y)        #呼叫時需要給定2個引數
print(dog)           #12
print(add2(45,54))   #99









