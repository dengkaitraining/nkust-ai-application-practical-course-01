import numpy as np
arr = np.array([45, 21, 33, 47, 59, 47, 43])
x = np.where(arr == 47)   
                     # 若找到的多個索引，索引會儲存在陣列內，而陣列則放在tuple的第一個元素
print(type(x))       # <class 'tuple'>
print(len(x))        #len(x)是1，也就是tuple只有一個元素，就是儲存索引的那個陣列
print(type(x[0]))    # numpy.ndarray
print(len(x[0]))     # 2，因為比對到2個47
print(x[0])          #  [3,5]，47分別落在索引編號為3及5的位置







 







 










