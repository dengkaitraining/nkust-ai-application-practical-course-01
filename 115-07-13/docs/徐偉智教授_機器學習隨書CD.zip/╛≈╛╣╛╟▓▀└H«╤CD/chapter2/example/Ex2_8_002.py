x=100           #Global Variable

def  myfun(a):
  x=300         # x 出現在等號左邊就是要定義local 變數
                # 因為是在函式內
  temp=a+x      # a 與  temp都是Local Variable，x則是Global Variabe100
  print(temp)

print(x)        # 100，Global Variable
myfun(400)      #700 帶入400 後加300 而不是加100










