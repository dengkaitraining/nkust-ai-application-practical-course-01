total=0
total=total+1  #將變數盒子tatal 的預設值設定為0
               #將total 的內容0 取出，加上1，得到結果1，存回total
total=total+2  #total內容為3
total=total+3  #total內容為6
total=total+4  #total內容為10
               #將total 的內容10 取出，加上5，得到結果15，存回total
total=total+5  #total內容為15 
print(total)   #結果為15


