
thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]

#一個一個元素印出
for x in thislist:
  print(x)





 










