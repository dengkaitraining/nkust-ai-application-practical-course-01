
import numpy as np                # 設定numpy的別名叫 np 
arr = np.array([1, 2, 3, 4, 5])
print(arr)
print(arr[2] + arr[3])            # 3 + 4 是7
print(arr[1:5:2])                 # 從第2個到第5個，每2個取1個，所以是[2,4] 
print(arr[::2])                   # 從第1個到最後一個，每2個取1個，[1,3,5] 







 










