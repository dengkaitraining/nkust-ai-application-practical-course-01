numlist=[23,45,78,12,-78,765]  #將數值存到陣列內
total=0
i=0
while (i < 6):                 #有6 個元素
  total=total + numlist[i]
  i=i+1
print(total)                   #845


 










