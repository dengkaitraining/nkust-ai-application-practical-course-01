d1 = 6 > 7
print(d1)
d2 = 6 <7
print(d2)
print()
print( d1 and d2)
print( d1 or d2)
print( d1 != d2)
print( not d1)
print( not d2)

