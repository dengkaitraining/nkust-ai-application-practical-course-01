numlist=[10,23,45,78,12,-78,765,98,34]  #將數值存到陣列內
total=0
N=len(numlist)
for i in range(0,N,1):
  total=total + numlist[i]
print(total)    #987



 










