thislist = ["orange", "mango", "kiwi"]
thislist.sort()
print(thislist)   #排序後的結果為 ["kiwi", "mango", "orange"]
dog= thislist.sort()
print(thislist)   #排序後的結果為 ["kiwi", "mango", "orange"]
thislist.sort(reverse=True)
print(thislist)   #排序後的結果為 ["orange", "mango","kiwi"]







 










