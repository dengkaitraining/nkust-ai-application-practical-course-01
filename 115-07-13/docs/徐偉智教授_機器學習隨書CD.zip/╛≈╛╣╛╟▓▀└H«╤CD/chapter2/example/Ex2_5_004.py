total=0
n=0   #現在計數器n改為0
while (n<10000):
  n=n+1   #n先加1
  if ( (n%7)==0 ):
     continue #若是7的倍數就不加
  total=total+n   
print(total) #結果為 42872858





