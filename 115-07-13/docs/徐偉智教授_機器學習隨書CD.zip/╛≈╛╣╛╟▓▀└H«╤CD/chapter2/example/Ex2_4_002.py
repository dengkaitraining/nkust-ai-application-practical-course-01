
dog = 100.3
if ( dog >= 100):
   print("dog是",dog)
   print("大於100所以執行這裡")
else:
   print("dog是", dog)
   print("小於100所以執行這裡")
