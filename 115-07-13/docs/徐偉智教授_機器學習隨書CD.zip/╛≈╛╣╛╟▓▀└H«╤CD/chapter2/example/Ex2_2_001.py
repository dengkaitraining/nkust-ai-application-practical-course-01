dog=168         # 命名一個變數 dog, 並將 168 儲存到 dog 內
print(dog)
dog=dog+100
print(dog)
dog=dog+100
print(dog)       # 將 dog 內容 368 取出再呈現出來
dog
