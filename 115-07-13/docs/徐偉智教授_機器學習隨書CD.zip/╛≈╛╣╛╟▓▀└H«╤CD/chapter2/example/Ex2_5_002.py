total=0
n=1
while (n<10001):
  total=total+n 
  n=n+1    　#改變終止條件之設定
print(total) #結果為 50005000



