total=0
for n in range(1,10001):
  if ( n%7 ==0 ):
    continue
  total=total+n
print(total)   #結果為42862858









