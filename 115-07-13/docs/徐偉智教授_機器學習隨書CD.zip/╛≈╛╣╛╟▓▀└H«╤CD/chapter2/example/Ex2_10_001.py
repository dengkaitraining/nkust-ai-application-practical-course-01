aStr = "Hello, World!"
aStr.upper()
print(aStr)           # Hello, World!
dog = aStr.upper()
print(dog)            # HELLO,WORLD!





 










