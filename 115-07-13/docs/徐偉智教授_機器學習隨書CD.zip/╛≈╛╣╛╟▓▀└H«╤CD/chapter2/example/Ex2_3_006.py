
print( 11%5 )
print( 11/5 )
print( 3**2 )
