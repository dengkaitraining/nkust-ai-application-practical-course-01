total=0
n=1      #現在計數器n改為1
while (n<10001):
  if ( (n%7)==0 ):
     n=n+1
     continue #若是7的倍數就不加
  total=total+n
  n=n+1
print(total) #結果為 42872858






