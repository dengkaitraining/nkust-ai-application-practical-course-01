import numpy as np
arr = np.array([ [[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]  ])
print("arr[0][1][2]的內容就是 ", arr[0][1][2])  # 6
print("arr[1][0][2]的內容就是 ", arr[1][0][2])  # 9









 










