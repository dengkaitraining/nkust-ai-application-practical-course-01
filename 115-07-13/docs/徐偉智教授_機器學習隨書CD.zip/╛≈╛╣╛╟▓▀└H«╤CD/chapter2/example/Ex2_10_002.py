thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist)
thislist.insert(1,"watermelon")
print(thislist)    # ['apple', 'watermelon', 'banana', 'cherry', 'orange']






 










