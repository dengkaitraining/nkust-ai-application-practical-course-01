import numpy as np
arr = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('第一列的第二個元素是: ', arr[0, 1])  # 2
print('(0,4)是', arr[0,4])                  # (0,4)是5
print('(1,3)是', arr[1,3])                  # (1,3)是9








 










