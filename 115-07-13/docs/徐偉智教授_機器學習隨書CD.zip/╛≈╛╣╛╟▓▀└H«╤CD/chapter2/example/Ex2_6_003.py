total=0
for n in range(1,10001):
  total=total+n
  if (total > 20000):
    break

print(total)   #結果為20100








