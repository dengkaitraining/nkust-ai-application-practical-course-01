x=100           #Global Variable

def  myfun(a):
  temp=a+x      # a 與  temp都是Local Variable，x則是Global Variabe100
  print(temp)

#print(temp)    #name not found error
print(x)        # 100
myfun(400)      # 500  










