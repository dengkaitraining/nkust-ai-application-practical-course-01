total=0
for n in range(1,10001):
  total=total+n
print(total)   #結果為50005000
for n in range(0,11,2):
  print(n)








