cat = 100/5
print(cat)
cat = 100*5
print(cat)
cat = 17 % 4
print(cat)
cat = 2**3
print(cat)
