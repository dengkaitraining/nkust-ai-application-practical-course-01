thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(thislist[2:5])  #cherry ,orange , kiwi
print(thislist[:4])   #等同thislist[0:4] 從apple起，取4個
print(thislist[-4:-1])  #從倒數第4個取到倒數第1個，orange到mango
thislist[1:2] = ["banana", "watermelon"] #相當於插入新元素watermelon
print(thislist[1:3])  # "banana", "watermelon"




 










