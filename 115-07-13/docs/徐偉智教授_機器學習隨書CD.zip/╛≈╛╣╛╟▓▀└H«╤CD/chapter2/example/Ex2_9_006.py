fruits = ["apple", "banana", "cherry",100]
x, y, z, d = fruits
print(x)
print(y)
print(z)
print(type(z))
print(d)
print(type(d))






 










