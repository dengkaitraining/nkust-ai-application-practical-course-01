
dog = "welcome!"
print(dog)
print("dog的內容是", dog)
