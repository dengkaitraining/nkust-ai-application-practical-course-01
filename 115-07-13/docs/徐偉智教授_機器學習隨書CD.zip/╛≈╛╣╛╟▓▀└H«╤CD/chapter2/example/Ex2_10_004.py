x = ["apple", "banana"]    #宣告一個陣列物件叫x
y = ["apple", "banana"]    #宣告另一個陣列物件叫y
z = x                      #原本叫x的櫃子，現在多了一個名稱叫z
print(x is z)              # x與z是否是指相同的櫃子，True
print(x is y)              # x與y是否是指相同的櫃子，False
print(x == y)              # x與y的櫃子內容是否相同，True
print(x==z)                # x與z的櫃子內容是否相同，True







 










