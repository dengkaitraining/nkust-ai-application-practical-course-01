
if ( 100>99):
  print(" I am here! ")
