total=0
n=1
while (n<10001):
  total=total+n 
  if (total > 20000):
    break
  n=n+1    #改變終止條件之設定
print(total) #結果為20100




