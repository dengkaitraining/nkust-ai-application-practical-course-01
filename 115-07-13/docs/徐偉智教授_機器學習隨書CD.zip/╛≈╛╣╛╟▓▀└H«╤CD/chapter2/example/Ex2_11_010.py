import numpy as np
arr = np.array([41, 42, 43, 44, 57])
filter_arr = []               # 建立空串列
for element in arr:
  if element > 42:
    filter_arr.append(True)   # 符合過濾條件的位置設定為True
  else:
    filter_arr.append(False)
newarr = arr[filter_arr]      # 將遮罩陣列套用到arr得到過濾後的新陣列
print(newarr)                 # [43 44 57]








 







 










