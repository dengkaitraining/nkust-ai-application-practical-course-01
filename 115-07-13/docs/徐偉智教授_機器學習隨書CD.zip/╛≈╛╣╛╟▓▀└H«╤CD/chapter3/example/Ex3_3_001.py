f = open("mydemofile.txt", "w")
f.write("1.第一行資料" + '\n')
f.write("2.第二行資料" + '\n')
f.write("3.第三行資料" + '\n')
f.close()

#open and read the file after writing:
f = open("mydemofile.txt", "r")
mystr=f.read()
print(mystr)
f.close()
