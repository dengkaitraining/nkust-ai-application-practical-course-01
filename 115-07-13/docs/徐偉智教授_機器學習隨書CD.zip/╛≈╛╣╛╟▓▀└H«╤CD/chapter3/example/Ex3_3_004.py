import pandas as pd

df = pd.read_csv('mydata.csv')

print("以下是 df 的內容：")
print(df.to_string()) 
