import pandas as pd

df = pd.read_json('myjson.json')
print(type(df))

print("以下是 df 的內容: ")
print(df.to_string()) 
