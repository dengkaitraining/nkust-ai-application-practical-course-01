score1=input("請輸入第一筆成績：")   #score1的型態是字串 
score2=input("請輸入第二筆成績：")   #將字串轉成浮點數才能做數值運算
x=float(score1)
y=float(score2)
avg=(x+y)/2
print("平均成績是",avg)


