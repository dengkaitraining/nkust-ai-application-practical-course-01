class Monkey:
  legs = 2
  hands= 2

monk=Monkey()        #呼叫預設建構子
print(monk.legs)     #物件.屬性 2
print(monk.hands)
monk2=Monkey()
print(monk.legs)     #物件.屬性 2
print(monk.hands)
