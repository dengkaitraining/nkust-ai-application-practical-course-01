x=90
try:
  y=0
  print(x/y)                     #預期會發生Exception
except:                          #萬一例外真的發生了，這裡就會被執行  
  print("An exception occurred") #An exception occurred
