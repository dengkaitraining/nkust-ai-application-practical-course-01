def myfunc(a):
  return len(a)

x = map(myfunc, ['apple', 'banana', 'cherry'])
                   #<map object at 0x000002485169E890> <class 'map'>
print(x,type(x))
                   #convert the map into a list
print(list(x))
