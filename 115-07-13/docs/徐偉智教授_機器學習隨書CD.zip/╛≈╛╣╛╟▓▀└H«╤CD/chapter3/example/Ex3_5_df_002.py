import pandas as pd
 
grades = {
    "name": ["Mary", "Tom", "Cindy", "Jane"],
    "math": [81, 15, 73, 82],
    "chinese": [64, 91, 86, 72]
}

print("使用字典建立df：") 
df = pd.DataFrame(grades)
print(df)

#使用字典增加一筆新資料紀錄
df=df.append({"name":"John", "math": 87, "chinese": 14}, ignore_index=True) 

df2 = pd.DataFrame({
    "name": ["Henry"],
    "math": [60],
    "chinese": [62]
})

#合併df新增資料紀錄
df = pd.concat([df, df2], ignore_index=True)
print(df)

#新增欄位及其值
df.insert(3, column="engilsh", value=[98, 72, 14, 98,56,64])
print(df)
 
