import numpy as np

def addw(x, y, w1, w2):
  return w1*x+w2*y

myadd = np.frompyfunc(addw, 4, 1)
result=myadd([1, 2, 3, 4], [5, 6, 7, 8], [0.3, 0.7, 0.6, 0.5],[0.7, 0.3, 0.4, 0.5] )
print(result)  #[3.8 3.1999999999999997 4.6 6.0]












 







 










