import mypackage
p5=mypackage.Human(3,5,7)
p5.talk()                 #我會說話!
print(p5.clothes)         #7
