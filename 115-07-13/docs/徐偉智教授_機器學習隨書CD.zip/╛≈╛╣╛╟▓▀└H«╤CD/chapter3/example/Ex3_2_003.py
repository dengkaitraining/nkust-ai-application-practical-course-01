import matplotlib.pyplot as plt
import numpy as np
y = np.array([3, 8, 1, 10])
plt.subplot(1, 3, 1)
plt.plot(y)
plt.title('Fig-a')
y = np.array([10, 20, 30, 40])
plt.subplot(1, 3, 2)
plt.plot(y)
plt.title('Fig-b')
y = np.array([3, 8, 1, 10])
plt.subplot(1, 3, 3)
plt.plot(y)
plt.title('Fig-c')
plt.show()


