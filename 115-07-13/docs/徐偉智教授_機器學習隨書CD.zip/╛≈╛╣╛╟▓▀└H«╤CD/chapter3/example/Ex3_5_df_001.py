import pandas as pd

df = pd.read_csv('Go_out_or_not.csv')
print(df)
X=df[["wType","Temp","Humidity"]]
y=df[["Travel"]]
print(X)  
print(y)
Z=X.values       #只取出內容，列與行的名稱都去掉
print(type(Z))   #(class 'numpy.ndarray')

