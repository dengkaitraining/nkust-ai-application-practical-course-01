import pandas as pd
grades = [
    ["Mary", 81, 64],
    ["Tom", 15, 91],
    ["Cindy", 73, 86],
    ["Jane", 82, 72]
]

print("使用陣列來建立df：")
X = pd.DataFrame(grades)
print(X)

X.index = ["A1", "A2", "A3", "A4"]  #自訂索引鍵值
X.columns = ["Sname", "math", "chinese"]  #自訂欄位名稱
print(X)

print("顯示索引鍵值A1與A3的資料紀錄")
print(X.loc[['A1','A3']])
print("取得資料索引值為0和2的第一個及第三個欄位的資料集")
print(X.iloc[[0 , 2], [0, 2]])
