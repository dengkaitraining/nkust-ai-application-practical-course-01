dogstr="taiwan"            #建立一個字串物件名稱為dogstr
catstr=dogstr.capitalize() #將第一個字母變大寫之後存在
print(dogstr)              #taiwan，本身沒有改變
print(catstr)              #Taiwan
cat=dogstr.upper() 
print(cat)                 #TAIWAN
duck=str(67.987)           #浮點數 67.987 型別轉換成 “67.987”
print(type(duck))          #<class 'str'> 
print(duck.find('9'))      #找到9回傳其index的編號 3
