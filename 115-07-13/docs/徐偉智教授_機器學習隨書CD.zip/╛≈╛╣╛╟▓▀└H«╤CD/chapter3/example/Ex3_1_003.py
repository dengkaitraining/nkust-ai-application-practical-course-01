import numpy as np

def add_2(x, y):
  return 0.5*x+0.5*y

myadd = np.frompyfunc(add_2, 2, 1)

result=myadd([1, 2, 3, 4], [5, 6, 7, 8])

print(result)     #[3.0 4.0 5.0 6.0]











 







 










