import numpy

simplearr= numpy.array([[1]])
print(type(simplearr))        # <class 'numpy.ndarray'>
print(type(simplearr[0]))    # <class 'numpy.ndarray'>
print(simplearr[0][0])        # 1

# 3維陣列 2x3x4
d = numpy.array([  [[1,2,3,4],[5,6,7,8],[9,10,11,12]],
                        [[13,14,15,16],[17,18,19,20],[21,22,23,24]]
                     ])
print(d[1][2][3])  #24
print(d[0][1][2])  #7

x1=numpy.array([1,2,3,4])
x2=numpy.array([5,6,7,8])
x3=numpy.array([9,10,11,12])

X1=numpy.stack((x1,x2,x3))         #3x4
print(X1)

X2=numpy.stack((x1,x2,x3),axis=1)  #4x3
print(X2)

X3=numpy.hstack((x1,x2,x3))        #一維陣列
print(X3)

X4=numpy.vstack((x1,x2,x3))        #4x3
print(X4)
print(X4[2,3])                     #12
