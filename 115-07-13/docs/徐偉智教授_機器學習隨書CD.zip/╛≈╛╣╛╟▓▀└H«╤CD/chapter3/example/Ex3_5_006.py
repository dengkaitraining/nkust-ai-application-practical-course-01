def myfunc(a, b):
  return a + b

dog=[1, 7, 9]
cat=[3, 8, 2]
x = map(myfunc, dog, cat)

tt=list(x)
print(tt)                 #[4,15,11] 
