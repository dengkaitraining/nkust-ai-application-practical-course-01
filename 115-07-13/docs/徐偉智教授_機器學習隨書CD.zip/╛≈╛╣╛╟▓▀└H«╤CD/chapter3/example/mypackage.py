class Monkey: 
  def __init__(self, num1, hands):
    self.legs = num1
    self.hands = hands 

class Human(Monkey):
 def __init__(self, legs, hands, clothes):
  super().__init__(legs, hands)  
  self.clothes=clothes
 def talk(self):
  print("我會說話!")
