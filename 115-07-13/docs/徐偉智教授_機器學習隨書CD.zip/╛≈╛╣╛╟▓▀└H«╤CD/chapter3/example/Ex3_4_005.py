class Monkey: 
  def __init__(self, num1, hands): #self就是自身，朕
    self.legs = num1
    self.hands = hands 
  def move(self,tool):  
    print("我走路用 " + str(self.legs) + " 隻腳與" + tool)

class Human(Monkey):
  def talk(self):
    print("我會說話!")

p4=Human(2,2)
print(p4.legs)
p4.move("拐杖")   #我走路用 2 隻腳與拐杖
print(p4.talk())  #我會說話!
