# Monkey類別有兩個屬性，分別是self.legs與self.hands的legs與hands
class Monkey: 
  def __init__(self, num1, hands): 
    self.legs = num1
    self.hands = hands

p1 = Monkey(3, 1)
print(p1.legs,p1.hands)    # 3,1
p2 = Monkey(4, 3)
print(p2.legs, p2.hands)   # 4,3
