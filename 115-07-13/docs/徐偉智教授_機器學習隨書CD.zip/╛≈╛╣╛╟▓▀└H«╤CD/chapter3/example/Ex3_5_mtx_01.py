import numpy as np

X = np.array([[2,1],
    [3,1],[4,1],[-1,1]])
print(X,"\n")       #4x2
Y=np.transpose(X)
print(Y,"\n")       #2x4

Z=X.dot(Y)          #X*Y
print(Z,"\n")       #4x4

W=Y.dot(X)          #Y*X
print(W,"\n")
