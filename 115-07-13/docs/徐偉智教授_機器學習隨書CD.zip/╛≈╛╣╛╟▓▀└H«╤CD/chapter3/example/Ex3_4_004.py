class Monkey: 
  def __init__(self, num1, hands):                 #self就是自身，朕
    self.legs = num1
    self.hands = hands 

  def move(self):                                  #定義一個move(…)方法
    print("我走路用 " + str(self.legs) + " 隻腳")

p2 = Monkey(4, 3)                                  #實際是呼叫__init__(...)
print(p2.hands)                                    #3
p2.move()                                          #我走路用 4 隻腳
