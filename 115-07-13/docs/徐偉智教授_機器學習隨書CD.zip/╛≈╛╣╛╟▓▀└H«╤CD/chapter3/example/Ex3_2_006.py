import matplotlib.pyplot as plt
import numpy as np

y = np.array([99,86,87,88,110,86,103,87,94,78,77,85,86,76,89,88,94,94,70,70])

plt.hist(y,bins=5)
plt.show() 
