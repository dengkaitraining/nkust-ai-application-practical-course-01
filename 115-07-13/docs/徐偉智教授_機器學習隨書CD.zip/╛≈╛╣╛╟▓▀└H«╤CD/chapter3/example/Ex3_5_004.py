quantity = 3
itemno = 123
price = 49
myorder = "I want {} pieces of item number {} for {:.2f} dollars."
#I want 3 pieces of item number 123 for 49.00 dollars.
print(myorder.format(quantity, itemno, price))
print(f'I want {quantity} pieces of item number {itemno} for {price:.2f} dollars.')
