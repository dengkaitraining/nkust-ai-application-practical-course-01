f = open("mydata.csv", "r")
ggg1=f.readline()
ggg2=f.readline()
ggg3=f.readline()
print(ggg1)  #Age,Experience,Rank,Nationality,Go
print(ggg2)  #36,10,9,UK,NO
print(ggg3)  #42,12,4,USA,NO
f.close()
