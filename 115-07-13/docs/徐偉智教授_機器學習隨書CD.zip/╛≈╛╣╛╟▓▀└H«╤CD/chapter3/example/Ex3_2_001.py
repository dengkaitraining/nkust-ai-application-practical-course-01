import matplotlib.pyplot as plt
import numpy as np

xpoints = np.array([0, 4, 6])
ypoints = np.array([0, 300, 250])

plt.plot(xpoints, ypoints)
plt.show()
