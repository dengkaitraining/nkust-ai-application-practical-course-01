class Monkey: 
  def __init__(self, num1, hands):
    self.legs = num1
    self.hands = hands 

class Human(Monkey):
 def __init__(self, legs, hands, clothes):
  super().__init__(legs, hands)  
  self.clothes=clothes
 def talk(self):
  print("我會說話!")
p5=Human(3,5,7)
p5.talk()                  #我會說話!
print(p5.clothes)          #7
