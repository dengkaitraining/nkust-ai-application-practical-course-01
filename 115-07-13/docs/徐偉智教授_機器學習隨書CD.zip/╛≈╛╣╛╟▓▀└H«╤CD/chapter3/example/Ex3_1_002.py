import numpy as np
arr = 2.0*np.arange(1, 5) + 6    # [1,2,3,4]
dog = np.log2(arr)                   #log2(...)就是ufunc
print(dog)          #[3.0 3.32192809 3.5849625  3.80735492]










 







 










