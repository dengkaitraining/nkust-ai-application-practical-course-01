f = open("mydemofile.txt", "r")
mystr=f.read(12)
print(mystr)
f.close()
