import json
x =  '{ "name":"John", "age":30, "city":"New York"}'
y = json.loads(x)
print(type(y))          #a Python dictionary, <class 'dict'>
print(y["age"])         #key --> value，30
