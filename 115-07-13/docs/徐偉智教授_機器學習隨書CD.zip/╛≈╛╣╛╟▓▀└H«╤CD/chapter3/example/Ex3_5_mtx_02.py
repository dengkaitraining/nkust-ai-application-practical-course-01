import numpy as np
X = np.matrix([[12,7,3],
    [4 ,5,6],
    [7 ,8,9]])

print(X,"\n")
#inv : inverse
#linalg : 線性代數

Y=np.linalg.inv(X)
print(Y,"\n")

Z=X.dot(Y)
print(np.round(Z,2))
