import math
import statistics as stats
from itertools import filterfalse

data = [20.7, float('NaN'),19.2, 18.3, float('NaN'), 14.4, 78.07, 21.88, 18.3]
print(list(map(math.isnan, data)))
N=sum(map(math.isnan, data)) 
print("非數值的筆數是:",N)
clean = list(filterfalse(math.isnan, data))  # Strip NaN values
x=stats.mean(clean)
print("平均數是: ",x)
x=stats.median(clean)
print("中位數是: ",x)
x=stats.mode(clean)
print("眾數是: ",x)
x=stats.stdev(clean)
print("標準差是: ",x)
x=stats.variance(clean)
print("變異數是: ",x)
print("變異數的開方根就是標準差: ", math.sqrt(x))
mydata=[1,2,3,4]
x=stats.quantiles(mydata, n=4)
print("25% 50% 75% 分位值是：",x)
