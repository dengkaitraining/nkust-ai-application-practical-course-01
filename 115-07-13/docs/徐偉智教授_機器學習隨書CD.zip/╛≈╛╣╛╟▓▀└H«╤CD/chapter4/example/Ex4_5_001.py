from sklearn import cluster


X=[[-3,2],[1,3],[4,4],[-5,-2],[2,-3]]

# KMeans 演算法
kmeans_fit = cluster.KMeans(n_clusters = 2).fit(X)
print(type(kmeans_fit))
# 印出分群結果
cluster_labels = kmeans_fit.labels_
print("分群結果：",cluster_labels)  # [0 1 1 0 1]
print(kmeans_fit.cluster_centers_)
