import numpy as np
a =np.array([3,4,5])
print(a.mean())

x = np.random.randn(100)
print(x.shape)            #(100,0) 表示是一個有100個元素的一維陣列
print(x[0])               #印出第一個元素的值 
print(x.mean())
x.sum()
x.min()
x.max()
