import statistics as stats
x = [1, 2, 3, 4, 5, 6, 7, 8, 9]
y = [1, 2, 3, 5, 6, 8, 6, 10, 11]
a=stats.covariance(x, x)
print("自己與自己的共變異數是 ",a)
a=stats.covariance(x, y)
print("自己與近似自己的共變異數是 ",a)
z = [12, 11, 10, 9, 8, 7, 6, 5, 4]
a=stats.covariance(x, z)
print("自己與自己倒反的共變異數是 ",a)
r=stats.correlation(x, x)
print("x與x的相關係數為 ", r)
r=stats.correlation(x,y)
print("x與y的相關係數為 ", r)
xdev=stats.stdev(x)
zdev=stats.stdev(z)
r=a/(xdev*zdev)
print("x與z的相關係數為 ", r) 
r=stats.correlation(x, z)
print("x與z的相關係數為 ", r)
