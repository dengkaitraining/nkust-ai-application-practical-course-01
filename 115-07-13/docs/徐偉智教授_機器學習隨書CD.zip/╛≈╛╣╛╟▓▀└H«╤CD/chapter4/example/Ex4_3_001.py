import numpy as np
from numpy import mean
from numpy import std
from numpy.random import randn
from numpy.random import seed
from matplotlib import pyplot
from scipy.stats import pearsonr

seed(150)
#相當於 data1 = 20 * randn(1000) + 5
data1=np.random.normal(loc=5, scale=20,size=1000)
noise = 10 * randn(1000) + 5
data2 = data1 + noise
# 初步摘要統計
print('data1: mean=%.3f stdv=%.3f' % (mean(data1), std(data1)))
print('data2: mean=%.3f stdv=%.3f' % (mean(data2), std(data2)))
covariance = np.cov(data1, data2)
print(covariance)

# calculate Pearson's correlation
corr,_= pearsonr(data1, data2)
print(f'Pearsons correlation: {corr:.3f}')

# plot
pyplot.scatter(data1, data2)
pyplot.show()


