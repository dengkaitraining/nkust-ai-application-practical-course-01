import math
import numpy as np
import statistics as stats
def getDist(a,b):
    temp=(a[0]-b[0])**2+(a[1]-b[1])**2
    dist=math.sqrt(temp)
    return dist

X=[[-3,2],[1,3],[4,4],[-5,-2],[2,-3]]
c1=[0,0]
c2=[0,0]

tot_x=0
tot_y=0
for a in X:
    tot_x=tot_x+a[0]
    tot_y=tot_y+a[1]

N=len(X)
c1[0]=tot_x/N + 0.5
c1[1]=tot_y/N + 0.5

c2[0]=tot_x/N - 0.5
c2[1]=tot_y/N - 0.5

CurTolDist=10000

count=0
while True:
    cluster1=[]
    cluster2=[]
    diss1=[]
    diss2=[]
    for a in X:
        diss1.append(getDist(a,c1))
        diss2.append(getDist(a,c2))
    j1=0
    j2=0
    sum1=0
    sum2=0
    for k in range(0,N):
        if (diss1[k]>diss2[k]):
            cluster2.append(X[k])
            j2+=1
            sum2+=diss2[k]
        else:
            cluster1.append(X[k])
            j1+=1
            sum1+=diss1[k]
    PreTolDist=CurTolDist
    CurTolDist=sum1+sum2
    
    tot_x1=0
    tot_y1=0
    for a in cluster1:
        tot_x1=tot_x1+a[0]
        tot_y1=tot_y1+a[1]
    c1[0]=tot_x1/len(cluster1)
    c1[1]=tot_y1/len(cluster1)
    tot_x2=0
    tot_y2=0
    for a in cluster2:
        tot_x2=tot_x2+a[0]
        tot_y2=tot_y2+a[1]
    c2[0]=tot_x2/len(cluster2)
    c2[1]=tot_y2/len(cluster2)
    if abs(PreTolDist-CurTolDist) < 0.001:
        break
    else:
        count+=1
print("分群結果:\n")
print("cluster1:",cluster1,"cluster1中心點:",c1,"\n")
print("cluster2:",cluster2,"cluster2中心點:",c2,"\n")
