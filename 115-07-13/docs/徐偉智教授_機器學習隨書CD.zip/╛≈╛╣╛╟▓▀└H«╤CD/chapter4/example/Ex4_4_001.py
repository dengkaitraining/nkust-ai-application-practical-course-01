import math
def getDist(a,b):
    temp=(a[0]-b[0])**2 + (a[1]-b[1])**2
    dist=math.sqrt(temp)
    return dist

p1=[-3,4]
p2=[2,4]

dist=getDist(p1,p2)

print("兩點之間的距離為: ",dist) #25
