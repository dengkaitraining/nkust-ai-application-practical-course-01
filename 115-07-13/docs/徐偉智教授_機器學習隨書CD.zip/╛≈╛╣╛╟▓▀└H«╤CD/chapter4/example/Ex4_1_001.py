import math
from numpy import random
import numpy as np


np.random.seed(150)
a1=np.random.uniform()
print(a1)  #a1型態為數值

a2=np.random.uniform(low=0.0, high=1.0, size=1)
print(a2)  #a2型態為List


a3=np.random.uniform(size=1)
print(a3)

a4=random.uniform(low=2.0, high=3.0, size=5)
print(a4)

