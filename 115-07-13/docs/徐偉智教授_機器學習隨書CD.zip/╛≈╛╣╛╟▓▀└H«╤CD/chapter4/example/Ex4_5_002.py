
from sklearn import datasets


# import some data to play with
iris = datasets.load_iris()
X = iris.data
Y = iris.target
print("X的資料型態為： " , type(X))
print("Y的資料型態為： ", type(Y))
print("資料筆數有", len(X), "筆")
print("setosa")
print(X[0:5,:],Y[0:5])
print("versicolor")
print(X[50:55,:],Y[50:55])
print("marginica")
print(X[100:105,:],Y[100:105])




