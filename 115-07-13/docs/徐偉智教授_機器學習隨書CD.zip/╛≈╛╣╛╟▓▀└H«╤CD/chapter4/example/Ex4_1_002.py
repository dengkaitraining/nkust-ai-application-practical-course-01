import math
from numpy import random
import numpy as np

count = np.array([0, 0, 0, 0, 0, 0])

for i in range(0,10000):
 val=random.uniform()
 val=math.floor(6*val)+1
 if (val==1):
   count[0]=count[0]+1
 if (val==2):
   count[1]=count[1]+1
 if (val==3):
   count[2]=count[2]+1
 if (val==4):
   count[3]=count[3]+1
 if (val==5):
   count[4]=count[4]+1
 if (val==6):
   count[5]=count[5]+1
 
print(count)
