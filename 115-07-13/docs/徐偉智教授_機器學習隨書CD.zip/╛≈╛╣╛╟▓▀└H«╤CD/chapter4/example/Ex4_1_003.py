import numpy as np

x = np.random.rand(2,3)
print("Array x:")
print(x)

print("\n Shape of Array x:")
print(x.shape)
