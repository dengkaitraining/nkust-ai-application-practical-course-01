import numpy as np
import math

N=5000
x = np.random.normal(loc=2,scale=4,size=(N))
m=np.mean(x)
print(m) 
xd=np.subtract(x,m)
x_sqr=np.power(xd,2)
x_sum=x_sqr.sum()

x_var=x_sum/(N-1)
print(x_var)                #變異數

x_var2=np.var(x)
print(x_var2)               #變異數

print(math.sqrt(x_var2))    #標準差
stdv=np.std(x)             
print(stdv)                 #標準差
