from numpy import random
import matplotlib.pyplot as plt


data = random.normal(loc=5, scale=3, size=(100000))
plt.hist(data,bins=100)
plt.show()
