from sklearn.datasets import load_iris
from sklearn import tree
import matplotlib.pyplot as plt
from sklearn.metrics import  confusion_matrix

iris = load_iris()
X = iris.data[50:149,:]
y = iris.target[50:149]

clf = tree.DecisionTreeClassifier(min_samples_split=6,max_depth=3)
clf = clf.fit(X, y)

testX=X
test_y=y
result=clf.predict(testX)
Mtx=confusion_matrix(test_y,result)
N=Mtx[0,0]+Mtx[0,1]+Mtx[1,0]+Mtx[1,1]
print("Accurancy is : ", ( Mtx[0,0]+Mtx[1,1])/N )
print("Sensitivity is : ", Mtx[0,0]/(Mtx[0,0]+Mtx[0,1]) )
print("Precision is : ",  Mtx[0,0]/(Mtx[0,0]+Mtx[1,0]) )
print("Speificity is : ",  Mtx[1,1]/(Mtx[1,0]+Mtx[1,1]) )      




