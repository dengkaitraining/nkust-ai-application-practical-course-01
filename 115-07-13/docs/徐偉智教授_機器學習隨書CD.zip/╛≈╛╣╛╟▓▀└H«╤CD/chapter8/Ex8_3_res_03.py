import numpy as np
from sklearn.linear_model import LinearRegression

X = np.array([[-3,2] ,[7,2],[3,-4],[6,7],[-5,-8],[7,9]])
y = np.array([[6], [5], [8],[2],[-2],[5]])

# y = a1 * x1 + a2*x2 + b
reg = LinearRegression().fit(X, y)
r2=reg.score(X,y)
print(f'R_square_value for 2 fields is {r2}')
k=2
N=6
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
print(f'Adj R2 for 2 fields is {Adj_R2}')

x1=X[:,0]
x2=X[:,1]
x3=X[:,0]*X[:,1]
X1=np.stack((x3,x2,x3),axis=1)
# y = a1 * x1 + a2*x2 + a3*x3 + b
reg = LinearRegression().fit(X1, y)
r2=reg.score(X1,y)
print(f'R_square_value for 3 fields is {r2}')
k=3
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
print(f'Adj R2 for 3 fields is {Adj_R2}')

x4=np.power(X[:,0],2.0)
X2=np.stack((x3,x2,x3,x4),axis=1)
# y = a1 * x1 + a2*x2 + a3*x3 + a4*x4 + b
reg = LinearRegression().fit(X2, y)
r2=reg.score(X2,y)
print(f'R_square_value for 4 fields is {r2}')
k=4
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
print(f'Adj R2 for 4 fields is {Adj_R2}')

