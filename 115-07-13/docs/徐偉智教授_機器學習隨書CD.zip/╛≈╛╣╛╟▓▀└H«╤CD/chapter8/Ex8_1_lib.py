from numpy import random
import numpy as np

def getTrnIdx(low,mpy,N):
 num=[]
 total=0
 n = int(low + np.floor(mpy*random.uniform(size=1)))
 num.append(n)
 total=total+1
 while (True):
    n = int(low + np.floor(mpy*random.uniform(size=1)))
    flag=1
    for i in num:
       if (n == i):
          flag=0
    if (flag == 0):
       continue
    else:
       num.append(n)
       total=total+1
    if total == N:
       return num

def getTestIdx(trnNum,low,high):
  testNum=[]
  for i in range(low,high):
    flag=1
    for n in trnNum:
       if (i == n):
           flag=0
    if (flag == 1):
      testNum.append(i)
  return testNum
