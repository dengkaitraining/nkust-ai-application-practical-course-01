import numpy as np
from numpy import random
import statsmodels.api as sm

random.seed(100)
a0=2.5
a1=-3.4
a2=6.7
N=200

x1=random.uniform(-10.0,10.0,size=(N,))
x2=random.uniform(-5.0,5.0,size=(N,))
e=random.normal(loc=0.0,scale=1.0,size=(N,))
y = a0+a1*np.power(x1,2.0) + a2*x2 + e #產生y


X = np.stack((x1,x2),axis=1) #y = a0 + a1*x1 + a2*x2
X2 = sm.add_constant(X)
model = sm.OLS(y, X2)
est2 = model.fit()
print(est2.summary())

x3=np.power(x1,2.0)
#y = a0 + a1*x1 + a2*x2 +a3*x1^2
X = np.stack((x1,x2,x3),axis=1) 
X2 = sm.add_constant(X)
model = sm.OLS(y, X2)
est2 = model.fit()
print(est2.summary())

x4=np.power(x1,2.0)
X = np.stack((x4,x2),axis=1) #y = a0 + a1*x1^2 + a2*x2
X2 = sm.add_constant(X)
model = sm.OLS(y, X2)
est2 = model.fit()
print(est2.summary())





