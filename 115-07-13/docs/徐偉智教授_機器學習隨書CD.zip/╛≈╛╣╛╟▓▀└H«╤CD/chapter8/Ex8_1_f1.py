from sklearn.datasets import load_iris
from sklearn import tree
from sklearn.metrics import  classification_report
import Ex9_1_lib as mylib

trnNum0=mylib.getTrnIdx(0,50,30)
testNum0=mylib.getTestIdx(trnNum0,0,50)
trnNum1=mylib.getTrnIdx(50,50,30)
testNum1=mylib.getTestIdx(trnNum1,50,100)
trnNum2=mylib.getTrnIdx(100,50,30)
testNum2=mylib.getTestIdx(trnNum2,100,150)

iris = load_iris()
X=[]
y=[]

for n in trnNum0:
    X.append(iris.data[n,:])
    y.append(iris.target[n])

for n in trnNum1:
    X.append(iris.data[n,:])
    y.append(iris.target[n])

for n in trnNum2:
    X.append(iris.data[n,:])
    y.append(iris.target[n])

clf = tree.DecisionTreeClassifier(min_samples_split=6,max_depth=3)
clf = clf.fit(X, y)

testX=[]
test_y=[]

for n in testNum0:
    testX.append(iris.data[n,:])
    test_y.append(iris.target[n])

for n in testNum1:
    testX.append(iris.data[n,:])
    test_y.append(iris.target[n])

for n in testNum2:
    testX.append(iris.data[n,:])
    test_y.append(iris.target[n])

result=clf.predict(testX)

#scores=classification_report(test_y,result,target_names=["setosa","versicolor","virginica"])
scores=classification_report(test_y,result,target_names=["setosa","versicolor","virginica"])
print(scores)


