from sklearn.datasets import load_iris
from sklearn import tree
from sklearn.metrics import  confusion_matrix
from numpy import random
import numpy as np
import Ex9_1_lib as mylib


trnNum1=mylib.getTrnIdx(50,50,30)
testNum1=mylib.getTestIdx(trnNum1,50,100)
trnNum2=mylib.getTrnIdx(100,50,30)
testNum2=mylib.getTestIdx(trnNum2,100,150)

iris = load_iris()
X=[]
y=[]
for n in trnNum1:
    X.append(iris.data[n,:])
    y.append(iris.target[n])

for n in trnNum2:
    X.append(iris.data[n,:])
    y.append(iris.target[n])

clf = tree.DecisionTreeClassifier(min_samples_split=6,max_depth=3)
clf = clf.fit(X, y)

testX=[]
test_y=[]
for n in testNum1:
    testX.append(iris.data[n,:])
    test_y.append(iris.target[n])

for n in testNum2:
    testX.append(iris.data[n,:])
    test_y.append(iris.target[n])

result=clf.predict(testX)
Mtx=confusion_matrix(test_y,result)
N=Mtx[0,0]+Mtx[0,1]+Mtx[1,0]+Mtx[1,1]
print("Accurancy is : ", ( Mtx[0,0]+Mtx[1,1])/N )
print("Sensitivity is : ", Mtx[0,0]/(Mtx[0,0]+Mtx[0,1]) )
print("Precision is : ",  Mtx[0,0]/(Mtx[0,0]+Mtx[1,0]) )
print("Speificity is : ",  Mtx[1,1]/(Mtx[1,0]+Mtx[1,1]) )      



