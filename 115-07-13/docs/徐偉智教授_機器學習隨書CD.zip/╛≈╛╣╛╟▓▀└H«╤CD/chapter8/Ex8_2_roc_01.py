from numpy import random
import numpy as np
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

M1=random.normal(loc=1.5, scale=0.45,size=(100,))
M2=random.normal(loc=1.0, scale=0.55,size=(100,))
D1=np.array([1]*100)
D2=np.array([0]*100)

Measure=np.hstack((M1,M2))
y=np.hstack((D1,D2))
print(np.round(Measure[97:105],2))
one_specificity = []
sensitivity = []
thr=[0.2,0.6,1.1,1.4,1.9,2.3]
for val in thr:
   result=[]
   for m in Measure:
      if (m >= val):
          result.append(1)
      else:
        result.append(0)
   cMtx = confusion_matrix(y,result)
   FPR  =  cMtx[1,0]/(cMtx[1,0]+cMtx[1,1])
   one_specificity.append(FPR)
   TPR  =  cMtx[0,0]/(cMtx[0,0]+cMtx[0,1])
   sensitivity.append(TPR)

plt.plot(one_specificity,sensitivity)
plt.plot([0.0,1.0],[0.0,1.0])
plt.show() 
