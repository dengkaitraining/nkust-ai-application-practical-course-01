import numpy as np
from sklearn.linear_model import LinearRegression
from numpy import random
from sklearn.metrics import mean_squared_error

def calculate_aic(n, mse, num_params):
	aic = n * np.log(mse) + 2 * num_params
	return aic


def calculate_bic(n, mse, num_params):
	bic = n * np.log(mse) + num_params * np.log(n)
	return bic

random.seed(100)
a0=2.5
a1=-3.4
a2=6.7
N=200

x1=random.uniform(-10.0,10.0,size=(N,))
x2=random.uniform(-5.0,5.0,size=(N,))
e=random.normal(loc=0.0,scale=1.0,size=(N,))
y = a0+a1*np.power(x1,2.0) + a2*x2 + e #產生y

X = np.stack((x1,x2),axis=1) #y = a0 + a1*x1 + a2*x2
reg = LinearRegression().fit(X, y)
a=[reg.intercept_,reg.coef_[0],reg.coef_[1]]
print(a)

r2=reg.score(X,y)
k=2
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
R=[r2,Adj_R2]
print(R)

y_est=reg.predict(X)
MSE=mean_squared_error(y,y_est)
AIC=calculate_aic(N, MSE, k)
BIC=calculate_bic(N, MSE, k)
abi=[AIC,BIC]
print(abi,'\n')

x3=np.power(x1,2.0)
#y = a0 + a1*x1 + a2*x2 + a3*x1^2 
X = np.stack((x1,x2,x3),axis=1)
reg = LinearRegression().fit(X, y)
a=[reg.intercept_,reg.coef_[0],reg.coef_[1],reg.coef_[2]]
print(a)

r2=reg.score(X,y)
k=3
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
R=[r2,Adj_R2]
print(R)

y_est=reg.predict(X)
MSE=mean_squared_error(y,y_est)
AIC=calculate_aic(N, MSE, k)
BIC=calculate_bic(N, MSE, k)
abi=[AIC,BIC]
print(abi,'\n')

x4=np.power(x1,2.0)
X = np.stack((x4,x2),axis=1) #y = a0 + a1*x1^2 + a2*x2
reg = LinearRegression().fit(X, y)
a=[reg.intercept_,reg.coef_[0],reg.coef_[1]]
print(a)

r2=reg.score(X,y)
k=2
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
R=[r2,Adj_R2]
print(R)

y_est=reg.predict(X)
MSE=mean_squared_error(y,y_est)
AIC=calculate_aic(N, MSE, k)
BIC=calculate_bic(N, MSE, k)
abi=[AIC,BIC]
print(abi,'\n')
