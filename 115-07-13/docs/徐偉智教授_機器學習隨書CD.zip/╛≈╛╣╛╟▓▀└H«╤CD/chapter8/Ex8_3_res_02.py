import numpy as np
from sklearn.linear_model import LinearRegression

X = np.array([[-3,2] ,[7,2],[3,-4],[6,7],[-5,-8],[7,9]])
y = np.array([[6], [5], [8],[2],[-2],[5]])

# y = a1 * x1 + a2*x2 + b
reg = LinearRegression().fit(X, y)
print(f'R_square_value for 2 fields is {reg.score(X,y)}')

x1=X[:,0]
x2=X[:,1]
x3=X[:,0]*X[:,1]
X1=np.stack((x3,x2,x3),axis=1)
# y = a1 * x1 + a2*x2 + a3*x3 + b
reg = LinearRegression().fit(X1, y)
print(f'R_square_value for 3 fields is {reg.score(X1,y)}')

x4=np.power(X[:,0],2.0)
X2=np.stack((x3,x2,x3,x4),axis=1)
# y = a1 * x1 + a2*x2 + a3*x3 + a4*x4 + b
reg = LinearRegression().fit(X2, y)
print(f'R_square_value for 4 fields is {reg.score(X2,y)}')

x5=np.power(X[:,1],2.0)
X3=np.stack((x3,x2,x3,x4,x5),axis=1)
# y = a1 * x1 + a2*x2 + a3*x3 + a4*x4 + a5*x5 + b
reg = LinearRegression().fit(X3, y)
print(f'R_square_value for 5 fields is {reg.score(X3,y)}')

x6=np.abs(X[:,0])
X4=np.stack((x3,x2,x3,x4,x5,x6),axis=1)
# y = a1 * x1 + a2*x2 + a3*x3 + a4*x4 + a5*x5 + a6*x6 + b
reg = LinearRegression().fit(X4, y)
print(f'R_square_value for 6 fields is {reg.score(X4,y)}')

