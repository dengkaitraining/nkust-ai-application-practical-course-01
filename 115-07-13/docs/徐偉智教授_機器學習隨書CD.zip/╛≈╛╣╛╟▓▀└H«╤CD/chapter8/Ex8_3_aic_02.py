import numpy as np
from sklearn.linear_model import LinearRegression
from numpy import random

a0=2.5
a1=-3.4
a2=6.7
N=200
x1=random.uniform(-10.0,10.0,size=(N,))
x2=random.uniform(-5.0,5.0,size=(N,))
e=random.normal(loc=0.0,scale=1.0,size=(N,))
X = np.stack((x1,x2),axis=1)
y = a0+a1*x1 +a2*x2 + e

reg = LinearRegression().fit(X, y)
print("a0 = ", reg.intercept_)
print("[a1,a2] = " ,reg.coef_)


r2=reg.score(X,y)
print(f'R2 = {r2}')
k=2
Adj_R2=1.0 - (1-r2)*(N-1)/(N-k-1)
print(f'Adj_R2 =  {Adj_R2}')

y_est=reg.predict(X)
error=y-y_est
MSE=np.sum(np.power(error,2))/N
AIC=2*k + N*np.log(MSE)
print(f'AIC = {AIC}')

BIC=k*np.log(N)+N*np.log(MSE)
print(f'BIC = {BIC}')
