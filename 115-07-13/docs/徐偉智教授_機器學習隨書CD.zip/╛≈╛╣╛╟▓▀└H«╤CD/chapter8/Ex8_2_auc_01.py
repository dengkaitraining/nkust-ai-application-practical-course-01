import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, roc_curve

n=10000                      #樣本數 
ratio = .75                  #75%為標記0
n_0 = int((1-ratio) * n)
n_1 = int(ratio * n)
#樣本的標記向量
true_y = np.array([0] * n_0 + [1] * n_1)
#分類器之樣本的度量值
measure_y = np.array(
    np.random.uniform(0, .7, n_0).tolist() +
    np.random.uniform(.3, 1, n_1).tolist()
)

auc=roc_auc_score(true_y, measure_y)
print(" AUC 為: ",auc)
fpr, tpr, thresholds = roc_curve(true_y, measure_y)
plt.plot(fpr, tpr)
plt.show()
