import numpy as np
from sklearn.linear_model import LinearRegression
from numpy import random
import matplotlib.pyplot as plt

random.seed(100)
a0=2.5
a1=-3.4
a2=6.7
N=200

#產生訓練資料集
x1=random.uniform(-10.0,10.0,size=(N,))
x2=random.uniform(-5.0,5.0,size=(N,))
e=random.normal(loc=0.0,scale=1.0,size=(N,))
y = a0+a1*np.power(x1,2.0) + a2*x2 + e 

#產生測試資料集
t_x1=random.uniform(-10.0,10.0,size=(1000,))
t_x2=random.uniform(-5.0,5.0,size=(1000,))
t_e=random.normal(loc=0.0,scale=1.0,size=(1000,))
t_y = a0+a1*np.power(t_x1,2.0) + a2*t_x2 + t_e

X = np.stack((x1,x2),axis=1) #y = a0 + a1*x1 + a2*x2
reg = LinearRegression().fit(X, y)
testX = np.stack((t_x1,t_x2),axis=1)
y_est=reg.predict(testX)
error=t_y-y_est
plt.hist(error)
plt.show()

x4=np.power(x1,2.0)
X = np.stack((x4,x2),axis=1) #y = a0 + a1*x1^2 + a2*x2
reg = LinearRegression().fit(X, y)
t_x4=np.power(t_x1,2.0)
testX = np.stack((t_x4,t_x2),axis=1)
y_est=reg.predict(testX)
error=t_y-y_est
plt.hist(error)
plt.show()


