import numpy as np
from sklearn.linear_model import LinearRegression

def estimate(a,b,x):
  est=a[0]*x[0]+a[1]*x[1]+b
  return est
    
X = np.array([[-3,2] ,[7,2],[3,-4],[6,7],[-5,-8],[7,9]])
y = np.array([[6], [5], [8],[2],[-2],[5]])
y_est = []

# 假設y = a1 * x1 + a2*x2 + b
reg = LinearRegression().fit(X, y)
a=reg.coef_[0]
b=reg.intercept_[0]

#基於求出的係數算出預測值
for x in X:
  y_est.append(estimate(a,b,x))
#誤差值向量
error=y[:,0]-y_est
MSE=np.sum(np.power(error,2))/6.0
print(f'MSE={MSE}')
y_bar=np.sum(y[:,0])/6.0
print(f'y_bar={y_bar}')
SSR=np.sum(np.power(y_est-y_bar,2))
print(f'SSR={SSR}')
SST=np.sum(np.power(y[:,0]-y_bar,2))
print(f'SST={SST}')
R_sqr_val=SSR/SST
print(f'決定係數 R^2={R_sqr_val}')
print("由模型算出的 R^2=",reg.score(X, y))
