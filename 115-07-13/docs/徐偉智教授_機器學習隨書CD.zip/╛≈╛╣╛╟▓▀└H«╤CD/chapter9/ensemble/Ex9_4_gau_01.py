from sklearn import datasets
from sklearn.ensemble import BaggingClassifier
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

iris=datasets.load_iris()
X=iris.data
y=iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y,test_size=0.2,random_state=10)

from sklearn import tree
from sklearn import svm
from sklearn.naive_bayes import GaussianNB

#clf=tree.DecisionTreeClassifier()
#clf=svm.SVC(kernel="linear")
#clf=GaussianNB()
clf=svm.SVC()

bagging=BaggingClassifier(base_estimator=clf,n_estimators=10,
                          bootstrap=True,bootstrap_features=True,
                          max_features=0.5,max_samples=0.7)
print(bagging)
bagging.fit(X_train,y_train)
bagging.predict(X_test)
sc1=bagging.score(X_train,y_train)
print(sc1)
sc2=bagging.score(X_test,y_test)
print(sc2)
plt.scatter(X[:,2],X[:,3],c=y)
plt.show()
