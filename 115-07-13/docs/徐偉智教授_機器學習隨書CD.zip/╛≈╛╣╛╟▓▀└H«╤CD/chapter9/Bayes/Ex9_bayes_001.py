from sklearn.naive_bayes import CategoricalNB
from sklearn.preprocessing import OrdinalEncoder
import pandas as pd
import numpy as np

df = pd.read_csv('Go_out_or_not.csv')
weather = df['weather_Type'].values.reshape(-1,1)
temp = df['Temp'].values.reshape(-1,1) 
humidity = df['Humidity'].values.reshape(-1,1)

# Using ordinal encoder to convert the categories 
# in the range from 0 to n-1
wea_enc = OrdinalEncoder()
weather_ = wea_enc.fit_transform(weather)
temp_enc = OrdinalEncoder()
temp_ = temp_enc.fit_transform(temp)
humidity_enc = OrdinalEncoder()
humidity_ = humidity_enc.fit_transform(humidity)
# Stacking all the features
X = np.column_stack((weather_,temp_,humidity_))
# Changing the type to int
X = X.astype(int)

"""
X=np.array([[0,2, 1], [1 ,2, 1], [1 ,2, 1], [2 ,1, 1],
 [2 ,0, 0], [2 ,0, 0], [1 ,0, 0], [0 ,1, 1], [0 ,0, 0],
 [2 ,1 ,0],[0 ,1, 0], [1 ,1 ,1], [1 ,2 ,0], [2 ,1 ,1],
 [2 ,2 ,1]])
"""
y=df["Travel"].values
clf = CategoricalNB()
clf.fit(X, y)
y_result = clf.predict(X)
print(y)
print(y_result)

