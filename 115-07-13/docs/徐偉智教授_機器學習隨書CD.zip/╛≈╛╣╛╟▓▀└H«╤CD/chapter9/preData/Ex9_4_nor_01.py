import pandas as pd
from sklearn import datasets
iris = datasets.load_iris()
x = pd.DataFrame(iris['data'], columns=['sep_L','sep_W','tep_L','tep_W'])
y = pd.DataFrame(iris['target'], columns=['target_names'])
data = pd.concat([x,y], axis=1)
print(data.head(3))
data['sep_L'] = (data['sep_L'] - data['sep_L'].min())/\
                            (data['sep_L'].max() - data['sep_L'].min())

data['sep_W'] = (data['sep_W'] - data['sep_W'].mean())/\
                            (data['sep_W'].std())
print(data.head(3))
