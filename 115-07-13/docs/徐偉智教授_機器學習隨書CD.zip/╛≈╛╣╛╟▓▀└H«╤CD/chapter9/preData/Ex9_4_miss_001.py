import numpy as np
import pandas as pd


df = pd.read_csv('expData.csv')
print(df)
newDf=df.dropna()
print(newDf)
newD=df.dropna(subset=['F5'])
#print(newDf)
df=df.dropna(how='all')
print(df)
df['F5'] = df['F5'].fillna(df['F5'].mean())
#print(df)
df['F4'] = df['F4'].fillna(df['F4'].mode())
#print(df)
df['F3'] = df['F3'].fillna(df['F3'].median())
#print(df)
df['F2'] = df['F2'].fillna(df['F2'].min())
print(df)
