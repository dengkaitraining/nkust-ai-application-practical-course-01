import pandas as pd

df = pd.DataFrame(
    [['goog', 'M', 10.9, 1],
    ['fair', 'L', 15.5, 2],
    ['bad', 'XL', 13.3, 1],
    ['good','S',20.6,2]]
)
df.columns = ['eval', 'size', 'price', 'label']
size_map = {
    'XL':4,
    'L':3,
    'M':2,
    'S':1
}
df['size'] = df['size'].map(size_map)
print(df)

onehot_encd = pd.get_dummies(df['eval'], prefix = 'eval')
df = df.drop('eval',axis=1)
newdf=pd.concat([onehot_encd, df],axis=1)
print(newdf)
