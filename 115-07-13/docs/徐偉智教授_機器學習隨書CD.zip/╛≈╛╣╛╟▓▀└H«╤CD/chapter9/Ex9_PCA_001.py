from sklearn.preprocessing import StandardScaler
from sklearn import datasets
from sklearn.decomposition import PCA
import pandas as pd
import matplotlib.pyplot as plt

iris = datasets.load_iris()
X=iris.data
y=iris.target
X = StandardScaler().fit_transform(X)

pca = PCA(n_components=4)
pcs = pca.fit_transform(X)
print("Information maintained for two pca : ")
print(pca.explained_variance_ratio_) #[0.72962445 0.22850762]
pcaDf = pd.DataFrame(data = pcs
             , columns = ['pca1', 'pca2'])
pcaDf["target"]=y

fig = plt.figure(figsize = (6,6))
ax = fig.add_subplot(1,1,1) 
ax.set_xlabel('Principal Component 1', fontsize = 15)
ax.set_ylabel('Principal Component 2', fontsize = 15)
ax.set_title('2 component PCA', fontsize = 20)
targets = [0, 1, 2]
colors = ['r', 'g', 'b']
for target, color in zip(targets,colors):
    indices = pcaDf['target'] == target
    ax.scatter(pcaDf.loc[indices, 'pca1']
               , pcaDf.loc[indices, 'pca2']
               , c = color
               , s = 50)
ax.legend(targets)
ax.grid()
plt.show()
