import numpy as np
import matplotlib.pyplot as plt

new_X=[-4.2,0.1]
X=np.array([[-1,-2],[-3,-1],[-5,-2],[-4,-2],[-1,4],[-3,4],[-2,3],[-3,2],[4,4],[4,6],[5,4],[3,5]])
y=['A','A','A','B','B','B','C','C','C']
Xa=X[0:4,0]; Ya=X[0:4,1];
Xb=X[4:8,0]; Yb=X[4:8,1];
Xc=X[8:12,0]; Yc=X[8:12,1];
plt.plot(Xa,Ya, 'x')
plt.plot(Xb,Yb, 'o')
plt.plot(Xc,Yc, '*')
plt.plot(new_X[0],new_X[1],'H',ms=18)
plt.text(-3, -2, 'A', fontsize = 18)
plt.text(-2, 5, 'B', fontsize = 18)
plt.text(4.8, 5.1, 'C', fontsize = 18)
plt.text(-5.2, -0.4, 'new_X(-4.2,0.1)', fontsize = 15)
plt.show()
