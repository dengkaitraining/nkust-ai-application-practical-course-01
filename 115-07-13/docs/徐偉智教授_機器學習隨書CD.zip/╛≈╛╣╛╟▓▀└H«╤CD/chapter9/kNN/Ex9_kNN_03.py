from sklearn import datasets
from sklearn.neighbors import KNeighborsClassifier
import numpy as np

new_X=[[-4.2,0.1]]
X=np.array([[-1,-2],[-3,-1],[-5,-2],[-4,-2],[-1,4],[-3,4],
            [-2,3],[-3,2],[4,4],[4,6],[5,4],[3,5]])
y=['A','A','A','A','B','B','B','B','C','C','C','C']

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X,y)
test_X=X
result=knn.predict(test_X)
print("以訓練資料集做為測試資料集的結果： " )
print(result)
print("new_X(-4.2,0.1)的分類結果: " , knn.predict(new_X))
