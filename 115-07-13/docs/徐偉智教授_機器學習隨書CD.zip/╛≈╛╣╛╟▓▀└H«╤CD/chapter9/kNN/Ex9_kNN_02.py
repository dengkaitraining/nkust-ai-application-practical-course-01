import math
import numpy as np
import matplotlib.pyplot as plt
def getDist(a,b):
    temp=(a[0]-b[0])**2+(a[1]-b[1])**2
    dist=math.sqrt(temp)
    return dist

dist=[]
new_X=[-4.2,0.1]
X=np.array([[-1,-2],[-3,-1],[-5,-2],[-4,-2],[-1,4],[-3,4],
            [-2,3],[-3,2],[4,4],[4,6],[5,4],[3,5]])
y=['A','A','A','A','B','B','B','B','C','C','C','C']
for  i in range(0,12):
    b=X[i]
    temp=getDist(new_X,b)
    dist.append(temp)

sorted_idx=sorted(range(len(dist)), key=lambda k: dist[k])
print("The index after sorting: ")
print(sorted_idx)
num_A=0; num_B=0; num_C=0;
for i in range(0,5):
    if (y[sorted_idx[i]]=="A"):
        num_A=num_A+1
    if (y[sorted_idx[i]]=="B"):
        num_B=num_B+1
    if (y[sorted_idx[i]]=="C"):
        num_C=num_C+1
        
if ((num_A > num_B) and (num_A > num_C)):
    isClass='A'
elif (num_B > num_C):
    isClass='B'
else:
    isClass='C'

print("This sample is classified as " + isClass)


