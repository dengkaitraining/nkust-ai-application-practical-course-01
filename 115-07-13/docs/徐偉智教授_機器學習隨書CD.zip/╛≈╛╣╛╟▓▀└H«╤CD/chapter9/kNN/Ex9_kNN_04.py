import numpy as np
from sklearn import neighbors, datasets
from sklearn import metrics



iris = datasets.load_iris()

X = iris.data
y = iris.target
for i in range(0,len(y)):
    if y[i]=="setosa":
        y[i]=0
    if y[i]=="versicolor":
        y[i]=1
    if y[i]=="virginica":
        y[i]=2

for k in [5,10,15,20]:
  clf = neighbors.KNeighborsClassifier(n_neighbors=k)
  clf.fit(X, y)
  res = clf.predict(X)
  print("當k值為 ", k , " 時，混淆矩陣為:")
  print(metrics.confusion_matrix(y, res))
  
