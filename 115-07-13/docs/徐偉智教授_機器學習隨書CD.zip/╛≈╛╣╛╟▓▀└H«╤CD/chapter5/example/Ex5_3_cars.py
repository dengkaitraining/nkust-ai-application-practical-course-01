import pandas
from sklearn import linear_model

df = pandas.read_csv("cars.csv")

X = df[['Weight', 'Volume']]
print(X)
y = df['CO2']

regr = linear_model.LinearRegression()
regr.fit(X, y)
a=regr.coef_
b=regr.intercept_
print(a)
print(b)

f=open("LR_model_01.txt","w")
f.write(str(a[0]))
f.write('\n')
f.write(str(a[1]))
f.write('\n')
f.write(str(b))
f.write('\n')
f.close()




