import numpy as np
from sklearn.linear_model import LinearRegression

error = np.random.normal(0.0, 1.0, size=(100,1))
X = np.random.uniform(low=-5, high=5, size=(100,2))
y =  np.random.uniform(low=-5, high=5, size=(100,1))

reg = LinearRegression().fit(X, y)
a=reg.coef_
c=reg.intercept_
print(f'Sklearn LR 的(a,b) = {a} ')
print(f'Sklearn LR 的c = {c}' )
print(f'R-squared value=  {reg.score(X, y)}')



