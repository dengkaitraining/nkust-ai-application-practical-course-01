import pandas as pd
import numpy as np
from sklearn import linear_model

df = pd.read_json('https://data.cityofnewyork.us/resource/dvzp-h4k9.json')

# return the column labels
col = df.columns

trainData = df[[col[15],col[17],col[24]]]
trainData= trainData.rename(columns={col[15]:'Units',col[17]:'SqFt'})
trainData= trainData.rename(columns={col[24]:'ValuePerSqFt'})

#印出前5列
print(trainData.head(5))

#轉成單一欄位的DataFrame
Units=trainData[['Units']]
SqFt=trainData[['SqFt']]
ValuePerSqFt=trainData[['ValuePerSqFt']]

#習慣上會轉成numpy的陣列
Units = np.array(Units)
SqFt=  np.array(SqFt)
ValuePerSqFt = np.array(ValuePerSqFt)

#組合成自變數陣列與依變數陣列
X = np.hstack((Units,SqFt))   # horizontal stack
y = ValuePerSqFt

regr = linear_model.LinearRegression()
regr.fit(X, y)
a=regr.coef_
b=regr.intercept_
print(a[0,0],a[0,1])  #[[-0.17078804  0.00022628]]
print(b[0])           #[180.97050412]
