def estimate(Volumn,Weight,a1,a2,b):
    val=a1*Volumn + a2*Weight + b
    return val

Volumn=input("請輸入Volumn: ")
Volumn=float(Volumn)
Weight=input("請輸入Weight: ")
Weight=float(Weight)

f=open("LR_model_01.txt","r")
a1=float(f.readline())
a2=float(f.readline())
b=float(f.readline())
f.close()

CO2_est=estimate(Volumn,Weight,a1,a2,b)
print(f'當Volumn={Volumn}，Weight={Weight}時，CO2是 {CO2_est}')
