import pandas
import numpy as np
from sklearn import linear_model
from sklearn.metrics import r2_score #
import matplotlib.pyplot as plt

stock = pandas.read_csv("teststock.csv")
print(type(stock)) #<class 'pandas.core.frame.DataFrame'>

mystock= np.array(stock) #30x1的二維陣列
stock=mystock[:,0]
print(stock[:3])    # [582 589 614]
print(stock[27:])   # [609 599 603]

N=len(stock)
print(N)
y=[ ]
x1=[ ]
x2=[ ]
x3=[ ]

for n in range(0,N-4):
 y.append(stock[n])    
 x1.append(stock[n+1])
 x2.append(stock[n+2])
 x3.append(stock[n+3])

X=np.stack((x1,x2,x3),axis=-1)
print(X[0:3,:])

regr = linear_model.LinearRegression()
regr.fit(X, y)
a=regr.coef_
b=regr.intercept_
print(a)  #print(a[0,0],a[0,1],a[0,2])  #[[-0.17078804  0.00022628]]
print(b)  #[180.97050412]
