import numpy as np
from sklearn.linear_model import LinearRegression
X = np.array([[2] ,[3],[4]])
y = np.array([[5], [8], [9]])
# y = a * x + b

reg = LinearRegression().fit(X, y)
print(f'R-squared value=  {reg.score(X, y)}')

a=reg.coef_
print(f'a= {a}')

b=reg.intercept_
print(f'b= {b}')

pred=reg.predict(np.array([[3]]))
print(f'x=3 的預測結果是: {pred}')

pred=reg.predict(np.array([[5]]))
print(f'x=5 的預測結果是: {pred}')

print(reg.aic)
