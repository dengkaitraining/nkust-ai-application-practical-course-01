import numpy as np

A = np.array([[2,3,5,1],[4,-2,-3,1],[3,4,-5,1],[5,2,-2,1],
                 [-3,6,8,1],[-5,7,2,1]])

z = np.array([[7],[9],[6],[11],[8],[3]])
             
At=np.transpose(A)
Z=At.dot(A)   #At*A

Y=np.linalg.inv(Z) #(At*A)^(-1)

B=Y.dot(At) #(At*A)^(-1)*At
s=B.dot(z)   #B*z
print("{a,b,c,d}: \n",s)

"""
 [[ 0.61943479]
 [-0.15917425]
 [ 0.29136194]
 [ 7.00167778]]
"""
