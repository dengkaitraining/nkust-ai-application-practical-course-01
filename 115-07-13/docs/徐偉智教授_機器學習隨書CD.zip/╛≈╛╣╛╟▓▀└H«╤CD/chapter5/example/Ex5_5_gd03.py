def errorfun(x):
  temp=(x-1)**2 + (x-3)**2 -5
  return temp

def partialfun(x):
  temp=4*x-8
  return temp 

pre_a=-1; stepS=0.05
tolence=0.00005
preErr=errorfun(pre_a)
flag=1;  iteration=1

while (flag==1):
 cur_a=pre_a - stepS*partialfun(pre_a)
 curErr=errorfun(cur_a)
 if (iteration % 2 != 0):
   print(iteration, ": " , cur_a, ";", curErr)
 if (abs(curErr-preErr) >= tolence):
    pre_a=cur_a
    preErr=curErr
    iteration= iteration+1  
 else:
    flag=0
print()
print("當 x= ",cur_a, " 時有最小值: ", curErr)
print("迭代總次數為: ",iteration)
