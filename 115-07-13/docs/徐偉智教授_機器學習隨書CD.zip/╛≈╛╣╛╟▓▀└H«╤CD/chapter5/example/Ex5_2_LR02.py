import numpy as np
from sklearn.linear_model import LinearRegression
X = np.array([[2,3,5] ,[4,-2,-3],[3,4,-5],[5,2,-2],[-3,6,8],[-5,7,2]])
y = np.array([[7], [9], [6],[11],[8],[3]])
# y = a * x1 + b*x2 + c*x3 + d

reg = LinearRegression().fit(X, y)
print(f'R-squared value=  {reg.score(X, y)}')

a=reg.coef_
print(f'abcd= {a}')

d=reg.intercept_
print(f'd= {d}')

pred=reg.predict(np.array([[2,3,5]]))
print(f'[2,3,5] 的預測結果是: {pred}')


