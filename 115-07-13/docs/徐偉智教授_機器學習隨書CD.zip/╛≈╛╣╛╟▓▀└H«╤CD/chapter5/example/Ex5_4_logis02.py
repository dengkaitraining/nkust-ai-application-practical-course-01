import numpy as np
from sklearn import linear_model
from sklearn import datasets

def sigmoid(u):
  val=1.0/(1+np.exp(-u))
  if val > 0.5:
    return int(1)
  else:
    return int(0)

ufun_sigmoid= np.frompyfunc(sigmoid, 1, 1) #universal function

# 讀入鳶尾花資料
iris = datasets.load_iris()
iris_X = iris.data[50:150,:]
y1=np.ones((50,1))
y0=np.zeros((50,1))

y=np.concatenate((y1, y0))
y = y.reshape(-1) #將100x1的二維陣列改為有100元素的1D array

logistic_regr = linear_model.LogisticRegression()
logistic_regr.fit(iris_X, y)

print(logistic_regr.intercept_)
print(logistic_regr.coef_)

w0=logistic_regr.intercept_[0]
w1=logistic_regr.coef_[0,0]
w2=logistic_regr.coef_[0,1]
w3=logistic_regr.coef_[0,2]
w4=logistic_regr.coef_[0,3]

u=w0 + w1*iris_X[:,0] + w2*iris_X[:,1]  + w3*iris_X[:,2] + w4*iris_X[:,3]

result=ufun_sigmoid(u)
print(result) 

