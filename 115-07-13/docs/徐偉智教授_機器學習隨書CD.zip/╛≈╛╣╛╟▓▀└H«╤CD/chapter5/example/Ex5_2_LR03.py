import numpy as np
from sklearn.linear_model import LinearRegression

error = np.random.normal(0.0, 1.0, size=(100,1))
X = np.random.uniform(low=-5, high=5, size=(100,2))
y=3.5*X[:,0] -5.6*X[:,1] -7.8  + error[:,0]  #a=3.5  b=-5.6 c=-7.8

reg = LinearRegression().fit(X, y)
a=reg.coef_
c=reg.intercept_
print(f'Sklearn LR 的(a,b) = {a} ')
print(f'Sklearn LR 的c = {c}' )
print(f'R-squared value=  {reg.score(X, y)}')



