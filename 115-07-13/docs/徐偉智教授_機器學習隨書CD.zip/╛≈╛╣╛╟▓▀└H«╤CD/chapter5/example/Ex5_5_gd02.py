import numpy as np
import matplotlib.pyplot as plt

def partialfun(x):
  temp=4*x-8
  return temp 

def f_x(x):
    a = (x - 1)**2 + (x - 3)**2 - 5
    return a

print(f_x(2))

y=[];a=[]
init=-2.0
end=6
N=int((end-init)/0.01)
print(N)
step=0.01
for i in range(1,N):
    a.append(init+i*step)
    val=f_x(a[i-1])
    y.append(val)
    
plt.plot(a,y)  #繪出曲線圖

xpartial=partialfun(-1.0)
c=f_x(-1.0)-xpartial*(-1.0)
xpoints=[-2.0,-1.0,0.0]
ypoints=[partialfun(-1.0)*(-2.0)+c,f_x(-1),c]
plt.plot(xpoints, ypoints,marker= 'o')     #繪出x=-2的偏微分斜率

xpartial=partialfun(5.0)
c=f_x(5.0)-xpartial*(5.0)
xpoints=[6.0,5.0,2.0]
ypoints=[partialfun(5.0)*(6.0)+c,f_x(5.0),partialfun(5.0)*(2.0)+c]
plt.plot(xpoints, ypoints,marker= 'o')     #繪出x=5.0的偏微分斜率

xpoints=[2.0]
ypoints=[f_x(2.0)]
plt.plot(xpoints, ypoints, 'x')
plt.show()   #繪出最低點
