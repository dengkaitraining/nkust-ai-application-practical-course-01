def errorfun(a,b,c,d):
  temp=(7-2*a-3*b-5*c-d)**2 + (9-4*a+2*b+3*c-d)**2 + (6-3*a-4*b+5*c-d)**2
  temp=temp+ (11-5*a-2*b+2*c-d)**2+(8+3*a-6*b-8*c-d)**2 + (3+5*a-7*b-2*c-d)**2
  return temp

def partialfun_a(a,b,c,d):
  temp=2*(7-2*a-3*b-5*c-d)*(-2)+2*(9-4*a+2*b+3*c-d)*(-4)+2*(6-3*a-4*b+5*c-d)*(-3)
  temp=temp + 2*(11-5*a-2*b+2*c-d)*(-5)+2*(8+3*a-6*b-8*c-d)*(3)+2*(3+5*a-7*b-2*c-d)*(5)
  return temp
def partialfun_b(a,b,c,d):
  temp=2*(7-2*a-3*b-5*c-d)*(-3)+2*(9-4*a+2*b+3*c-d)*(2)+2*(6-3*a-4*b+5*c-d)*(-4)
  temp=temp + 2*(11-5*a-2*b+2*c-d)*(-2)+2*(8+3*a-6*b-8*c-d)*(-6)+2*(3+5*a-7*b-2*c-d)*(-7)
  return temp

def partialfun_c(a,b,c,d):
  temp=2*(7-2*a-3*b-5*c-d)*(-5)+2*(9-4*a+2*b+3*c-d)*(3)+2*(6-3*a-4*b+5*c-d)*(5)
  temp=temp + 2*(11-5*a-2*b+2*c-d)*(2)+2*(8+3*a-6*b-8*c-d)*(-8)+2*(3+5*a-7*b-2*c-d)*(-2)
  return temp
def partialfun_d(a,b,c,d):
  temp=2*(7-2*a-3*b-5*c-d)*(-1)+2*(9-4*a+2*b+3*c-d)*(-1)+2*(6-3*a-4*b+5*c-d)*(-1)
  temp=temp + 2*(11-5*a-2*b+2*c-d)*(-1)+2*(8+3*a-6*b-8*c-d)*(-1)+2*(3+5*a-7*b-2*c-d)*(-1)
  return temp
old_a=0.7; old_b=-0.2; old_c=0.32; old_d=5; stepsize=0.000001; tolence=0.000000005
preErr=errorfun(old_a,old_b,old_c,old_d) ;  flag=1;  iteration=1

print("真正的答案：",0.62,-0.16,0.29,7.0,errorfun(0.62,-0.16,0.29,7.0)) 

while (flag==1):
 new_a=old_a - stepsize*partialfun_a(old_a,old_b,old_c,old_d)
 new_b=old_b - stepsize*partialfun_b(old_a,old_b,old_c,old_d)
 new_c=old_c - stepsize*partialfun_c(old_a,old_b,old_c,old_d)
 new_d=old_d - stepsize*partialfun_d(old_a,old_b,old_c,old_d)

 curErr=errorfun(new_a,new_b,new_c,new_d)
 if (abs(curErr-preErr) >= tolence):
    old_a=new_a; old_b=new_b; old_c=new_c;  old_d=new_d ; preErr=curErr;      iteration= iteration+1  
 else:
    flag=0
print("a,b,c,d= ",round(new_a,2), ",",round(new_b,2), ",",
      round(new_c,2), ",",round(new_d,2), " 時有最小值: ", curErr)
print(" 迭代總次數為:", iteration)
