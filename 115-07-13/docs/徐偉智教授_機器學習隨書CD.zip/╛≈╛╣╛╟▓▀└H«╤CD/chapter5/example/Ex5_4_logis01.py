import numpy as np
from sklearn import linear_model

def sigmoid(u):
  val=1.0/(1+np.exp(-u))
  return val

ufun_sigmoid= np.frompyfunc(sigmoid, 1, 1)

X = np.array([[2.5,1.5] ,[-1.7, 2.7],[-1.8,-0.9],[1.6,-1.3]])
y = np.array([[1], [1], [0],[0]])

logistic_regr = linear_model.LogisticRegression()
logistic_regr.fit(X, y)
w0=logistic_regr.intercept_[0]
w1=logistic_regr.coef_[0,0]
w2=logistic_regr.coef_[0,1]

print(w0,w1,w2) #[-0.53125836] [[0.20039829 1.00704966]]

u=w0 + w1*X[:,0] + w2*X[:,1]
print(u)        #[1.48031185  1.84709861 -1.79831998 -1.51978565]

result=ufun_sigmoid(u)
print(result)   #[0.814619 0.863786 0.142055 0.179493]
