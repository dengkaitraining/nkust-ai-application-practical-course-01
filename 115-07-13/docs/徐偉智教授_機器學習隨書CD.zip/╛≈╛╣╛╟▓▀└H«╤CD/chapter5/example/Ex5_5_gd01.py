import numpy as np
import matplotlib.pyplot as plt

def f_x(x):
    a = (x - 1)**2 + (x - 3)**2 - 5
    return a

print(f_x(2))

y=[]
a=[]
init=-2.0
end=6
N=int((end-init)/0.01)
print(N)
step=0.01
for i in range(1,N):
    a.append(init+i*step)
    val=f_x(a[i-1])
    y.append(val)
    
plt.plot(a,y)
plt.show()
    
